// پیکربندیِ بانک رسالت (اینترنت‌بانکِ vbank.rqb.ir، درگاهِ داده sec.rqb.ir).
// ساختار از پروژهٔ BankHub خودتان گرفته شده (Modules/Resalat).
// افزونه فقط بعد از ورودِ خودِ کاربر و از داخلِ همان صفحه داده می‌گیرد؛ چون F5 درخواستِ بیرونی را رد می‌کند.

export const RESALAT = {
  id: 'resalat',
  title: 'بانک رسالت',
  loginHost: 'oauth.rqb.ir',       // فرمِ LoginProcess این‌جاست (از vbank هدایت می‌شود)
  appHost: 'vbank.rqb.ir',         // پس از ورود
  gateway: 'https://sec.rqb.ir',   // درگاهِ /pols/
  depositPage: 'https://vbank.rqb.ir/vbank/mb/deposit/depositInvoice',
  currency: '364',                 // ریال
  sidAttr: 'data-zamani-sid',      // پلِ MAIN→ISOLATED برای X-Tab-Session-ID

  selectors: {
    username: ['#Username', "input[name='Username']", "input[type='text']"],
    password: ['#Password', "input[name='Password']", "input[type='password']"],
    submit: ['#btnLoginProcess', "button[type='submit']"],
    captchaImage: ['#captchaImage'],
    captcha: ['#Captcha'],
  },

  api: {
    deposits: '/pols/deposits/without-amount',
    invoice: '/pols/deposits/extended-invoice',
  },
};

// بازه‌های آماده — با تاریخِ میلادی کار می‌کنند (درخواستِ رسالت ISO میلادی می‌خواهد)
export const RESALAT_RANGES = [
  { id: 'd30', title: '۳۰ روز اخیر', days: 30 },
  { id: 'd90', title: '۹۰ روز اخیر', days: 90 },
  { id: 'd180', title: '۱۸۰ روز اخیر', days: 180 },
  { id: 'c50', title: '۵۰ تراکنش آخر', count: 50 },
  { id: 'c200', title: '۲۰۰ تراکنش آخر', count: 200 },
];

/** بدنهٔ POST extended-invoice برای یک سپرده و یک بازه. */
export function buildInvoiceRequest(depositNumber, range, currency = RESALAT.currency) {
  const req = {
    depositNumber,
    currency,
    includeDebtor: true,
    includeCreditor: true,
    isAscendingByDate: false,
    includeAdvancedSearch: false,
    isSearchedByDate: false,
    recordCount: 0,
    startDate: '0001-01-01T00:00:00.000Z',
    endDate: '0001-01-01T00:00:00.000Z',
  };
  if (range.count) {
    req.recordCount = range.count;
  } else {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - (range.days || 30));
    from.setHours(0, 0, 0, 0);
    to.setHours(23, 59, 59, 0);
    req.isSearchedByDate = true;
    req.startDate = from.toISOString().replace(/\.\d+Z$/, '.000Z');
    req.endDate = to.toISOString().replace(/\.\d+Z$/, '.000Z');
  }
  return req;
}
