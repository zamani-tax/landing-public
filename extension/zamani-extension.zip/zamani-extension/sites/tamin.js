// پیکربندیِ سامانهٔ تأمین اجتماعی — برگرفته از ZamaniDataSync (scripts/tamin_auth.py و TaminHttpClient.cs).
// این فایل عمداً «داده» است نه منطق، تا در نسخه‌های بعد بتوان آن را از سرور به‌روز کرد.

const CLIENT_ID = '1e3923181a0818041c1d192c3805040f';
const REDIRECT_URI = 'https://eservices.tamin.ir/auth/access';

export const TAMIN = {
  id: 'tamin',
  title: 'تأمین اجتماعی',
  loginHost: 'account.tamin.ir',
  appHost: 'eservices.tamin.ir',
  // مسیرِ assertion از چالشِ ضدرباتِ داشبورد عبور نمی‌کند و مستقیم به eservices برمی‌گردد
  authorizeUrl:
    'https://account.tamin.ir/auth/server/authorize' +
    `?redirect_uri=${REDIRECT_URI}&response_type=assertion&client_id=${CLIENT_ID}`,

  selectors: {
    username: ['input.username', "input[placeholder='نام کاربری']", "input[type='text']"],
    password: ['input.password', "input[placeholder='گذرواژه']", "input[type='password']"],
    submit: ["button[type='submit'].login-button", "button[type='submit']", 'button.login-button'],
  },

  api: {
    eservices: 'https://eservices.tamin.ir/api',
    celist: 'https://celist.tamin.ir/taxlist/api',
  },

};

// اقدام‌هایی که کاربر می‌تواند با یک کلیک اجرا کند
export const TAMIN_ACTIONS = [
  { id: 'login', title: 'فقط ورود' },
  { id: 'sync', title: 'ورود + همگام‌سازی کامل' },
];
