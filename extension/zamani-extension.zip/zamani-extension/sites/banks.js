// پیکربندیِ بانک‌های پشتیبانی‌شده. سه «خانواده»:
//   datin  → رسالت/پاسارگاد/گردشگری (API یکسانِ /pols، هدرِ X-Tab-Session-ID). دریافتِ زنده + فایل.
//   saman  → بانک سامان (API webbank، توکنِ csrf از localStorage). دریافتِ زنده + فایل.
//   shahr  → بانک شهر (اپِ Struts). فقط کمک‌به‌ورود + خواندنِ فایل (API زندهٔ آن حتی در BankHub هم نگاشت نشده).
// ساختار از پروژهٔ BankHub خودتان گرفته شده. افزونه فقط از داخلِ تبِ زندهٔ خودِ کاربر داده می‌گیرد.

// ── خانوادهٔ داتین (مشترک) ──
export const DATIN = {
  currency: '364',
  sidAttr: 'data-zamani-sid',
  depositPagePath: '/vbank/mb/deposit/depositInvoice',
  selectors: {
    username: ['#Username', "input[name='Username']", "input[type='text']"],
    password: ['#Password', "input[name='Password']", "input[type='password']"],
    submit: ['#btnLoginProcess', "button[type='submit']"],
    captchaImage: ['#captchaImage'],
    captcha: ['#Captcha'],
  },
  api: { deposits: '/pols/deposits/without-amount', invoice: '/pols/deposits/extended-invoice' },
};

// ── خانوادهٔ سامان ──
export const SAMAN = {
  host: 'ib.sb24.ir',
  apiPath: '/webbank/api',
  statementPath: '/billStatement/depositBill',
  pageSize: 50,
  maxRangeDays: 31,   // سامان بازهٔ بزرگ‌تر را با ۵۰۰ رد می‌کند
  tz: 'Asia/Tehran',
};

// ── خانوادهٔ شهر (فقط ورود + فایل) ──
export const SHAHR = {
  host: 'ebank.shahr-bank.ir',
  selectors: {
    username: ["input[name='username']", '#username'],
    password: ["input[name='password']", '#password'],
    captchaImage: ["img[src*='captcha']"],
    captcha: ["input[name='captcha']", '#captcha'],
  },
};

// رجیستریِ همهٔ بانک‌ها. code/slug همان‌هایی‌اند که سمتِ حسابداری می‌شناسد.
export const BANKS = [
  { id: 'resalat', code: 'Resalat', slug: 'resalat', title: 'بانک رسالت', family: 'datin',
    loginHost: 'oauth.rqb.ir', appHost: 'vbank.rqb.ir', gateway: 'https://sec.rqb.ir' },
  { id: 'pasargad', code: 'Pasargad', slug: 'pasargad', title: 'بانک پاسارگاد', family: 'datin',
    loginHost: 'oauth.bpi.ir', appHost: 'vbank.bpi.ir', gateway: 'https://sec.bpi.ir' },
  { id: 'gardeshgari', code: 'Gardeshgari', slug: 'gardeshgari', title: 'بانک گردشگری', family: 'datin',
    loginHost: 'oauth.tourismbank.ir', appHost: 'vbank.tourismbank.ir', gateway: 'https://sec.tourismbank.ir' },
  { id: 'saman', code: 'Saman', slug: 'saman', title: 'بانک سامان', family: 'saman', host: SAMAN.host },
  { id: 'shahr', code: 'Shahr', slug: 'shahr', title: 'بانک شهر', family: 'shahr', host: SHAHR.host },
];

export const bankById = (id) => BANKS.find((b) => b.id === id) || null;

/** بانکِ متناظر با یک hostname و اینکه صفحهٔ ورود است یا اپ. */
export function bankByHost(hostname) {
  const h = String(hostname || '').toLowerCase();
  for (const b of BANKS) {
    if (b.family === 'datin') {
      if (h === b.loginHost) return { bank: b, onLogin: true };
      if (h === b.appHost) return { bank: b, onLogin: false };
    } else if (h === b.host) {
      // سامان: حالتِ دریافت. شهر: حالتِ ورود (دریافتِ زنده ندارد).
      return { bank: b, onLogin: b.family === 'shahr' };
    }
  }
  return { bank: null, onLogin: false };
}

/** آیا این بانک دریافتِ یک‌کلیکِ زنده دارد؟ (شهر ندارد) */
export const bankCanFetch = (bank) => !!bank && bank.family !== 'shahr';

// بازه‌های آماده به تفکیکِ خانواده
const DATIN_RANGES = [
  { id: 'd30', title: '۳۰ روز اخیر', days: 30 },
  { id: 'd90', title: '۹۰ روز اخیر', days: 90 },
  { id: 'd180', title: '۱۸۰ روز اخیر', days: 180 },
  { id: 'c50', title: '۵۰ تراکنش آخر', count: 50 },
  { id: 'c200', title: '۲۰۰ تراکنش آخر', count: 200 },
];
const SAMAN_RANGES = [
  { id: 'd30', title: '۳۰ روز اخیر', days: 30 },
  { id: 'd90', title: '۹۰ روز اخیر', days: 90 },
  { id: 'd180', title: '۱۸۰ روز اخیر', days: 180 },
];
export const rangesFor = (bank) => (bank?.family === 'saman' ? SAMAN_RANGES : DATIN_RANGES);

/** بدنهٔ POST extended-invoice برای داتین. */
export function buildInvoiceRequest(depositNumber, range, currency = DATIN.currency) {
  const req = {
    depositNumber, currency,
    includeDebtor: true, includeCreditor: true,
    debtorAmountFrom: null, debtorAmountTo: null, creditorAmountFrom: null, creditorAmountTo: null,
    isAscendingByDate: false, isSearchedByDate: false, includeAdvancedSearch: false,
    recordCount: 0, startDate: '0001-01-01T00:00:00.000Z', endDate: '0001-01-01T00:00:00.000Z',
  };
  if (range.count) {
    req.recordCount = range.count;
  } else {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - (range.days || 30));
    from.setHours(0, 0, 0, 0);
    to.setHours(23, 59, 59, 0);
    req.isSearchedByDate = true;
    req.startDate = from.toISOString().replace(/\.\d+Z$/, '.000Z');
    req.endDate = to.toISOString().replace(/\.\d+Z$/, '.999Z');
  }
  return req;
}

/** پنجره‌های میلادیِ UTC برای سامان: کلِ بازه به تکه‌های ≤maxDays روز. جدیدترین اول. */
export function samanWindows(days, maxDays = SAMAN.maxRangeDays) {
  const iso = (d) => d.toISOString().replace(/\.\d+Z$/, '.000Z');
  const now = new Date();
  const start = new Date(now.getTime() - days * 86400000);
  const wins = [];
  let toT = now.getTime();
  const startT = start.getTime();
  while (toT > startT) {
    const fromT = Math.max(startT, toT - maxDays * 86400000);
    wins.push({ from: iso(new Date(fromT)), to: iso(new Date(toT)) });
    toT = fromT - 1000;
  }
  return wins;
}
