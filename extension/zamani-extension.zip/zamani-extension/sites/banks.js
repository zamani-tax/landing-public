// پیکربندیِ بانک‌های خانوادهٔ «داتین» (همان سکوی رسالت).
// این بانک‌ها API یکسان دارند (/pols/deposits، هدرِ X-Tab-Session-ID، بدنه و پاسخِ یکسان)
// و فقط در هاست‌ها فرق دارند. ساختار از پروژهٔ BankHub خودتان گرفته شده (Modules/*).
// افزونه فقط بعد از ورودِ خودِ کاربر و از داخلِ همان صفحه داده می‌گیرد (WAFِ بانک درخواستِ بیرونی را رد می‌کند).

// مشترکِ همهٔ بانک‌های داتین
export const DATIN = {
  currency: '364',              // ریال
  sidAttr: 'data-zamani-sid',   // پلِ MAIN→ISOLATED برای X-Tab-Session-ID
  depositPagePath: '/vbank/mb/deposit/depositInvoice',
  selectors: {
    username: ['#Username', "input[name='Username']", "input[type='text']"],
    password: ['#Password', "input[name='Password']", "input[type='password']"],
    submit: ['#btnLoginProcess', "button[type='submit']"],
    captchaImage: ['#captchaImage'],
    captcha: ['#Captcha'],
  },
  api: {
    deposits: '/pols/deposits/without-amount',
    invoice: '/pols/deposits/extended-invoice',
  },
};

// هر بانک: id/کد/عنوان + سه هاست (ورود، اپ، درگاه). کد و اسلاگ همان‌هایی‌اند که سمتِ حسابداری می‌شناسد.
export const DATIN_BANKS = [
  {
    id: 'resalat', code: 'Resalat', slug: 'resalat', title: 'بانک رسالت',
    loginHost: 'oauth.rqb.ir', appHost: 'vbank.rqb.ir', gateway: 'https://sec.rqb.ir',
  },
  {
    id: 'pasargad', code: 'Pasargad', slug: 'pasargad', title: 'بانک پاسارگاد',
    loginHost: 'oauth.bpi.ir', appHost: 'vbank.bpi.ir', gateway: 'https://sec.bpi.ir',
  },
  {
    id: 'gardeshgari', code: 'Gardeshgari', slug: 'gardeshgari', title: 'بانک گردشگری',
    loginHost: 'oauth.tourismbank.ir', appHost: 'vbank.tourismbank.ir', gateway: 'https://sec.tourismbank.ir',
  },
];

export const datinBankById = (id) => DATIN_BANKS.find((b) => b.id === id) || null;

/** بانکِ متناظر با یک hostname و اینکه صفحهٔ ورود است یا اپ. */
export function datinBankByHost(hostname) {
  const h = String(hostname || '').toLowerCase();
  for (const b of DATIN_BANKS) {
    if (h === b.loginHost) return { bank: b, onLogin: true };
    if (h === b.appHost) return { bank: b, onLogin: false };
  }
  return { bank: null, onLogin: false };
}

// بازه‌های آماده — با تاریخِ میلادی کار می‌کنند (درخواست ISO میلادی می‌خواهد)
export const DATIN_RANGES = [
  { id: 'd30', title: '۳۰ روز اخیر', days: 30 },
  { id: 'd90', title: '۹۰ روز اخیر', days: 90 },
  { id: 'd180', title: '۱۸۰ روز اخیر', days: 180 },
  { id: 'c50', title: '۵۰ تراکنش آخر', count: 50 },
  { id: 'c200', title: '۲۰۰ تراکنش آخر', count: 200 },
];

/** بدنهٔ POST extended-invoice برای یک سپرده و یک بازه (یکسان برای همهٔ بانک‌های داتین). */
export function buildInvoiceRequest(depositNumber, range, currency = DATIN.currency) {
  const req = {
    depositNumber,
    currency,
    includeDebtor: true,
    includeCreditor: true,
    debtorAmountFrom: null,
    debtorAmountTo: null,
    creditorAmountFrom: null,
    creditorAmountTo: null,
    isAscendingByDate: false,
    isSearchedByDate: false,
    includeAdvancedSearch: false,
    recordCount: 0,
    startDate: '0001-01-01T00:00:00.000Z',
    endDate: '0001-01-01T00:00:00.000Z',
  };
  if (range.count) {
    req.recordCount = range.count;
  } else {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - (range.days || 30));
    from.setHours(0, 0, 0, 0);
    to.setHours(23, 59, 59, 0);
    req.isSearchedByDate = true;
    req.startDate = from.toISOString().replace(/\.\d+Z$/, '.000Z');
    req.endDate = to.toISOString().replace(/\.\d+Z$/, '.999Z');
  }
  return req;
}
