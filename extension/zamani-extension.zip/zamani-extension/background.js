// مغزِ افزونه: گاوصندوق، پر کردنِ فرم ورود، و اجرای اقدام‌های چندمرحله‌ای.
// رمزها فقط این‌جا دیده می‌شوند؛ پنل فقط نمای بدونِ رمز می‌گیرد و content script هیچ رمزی نمی‌گیرد
// (پر کردنِ فرم مستقیم با executeScript در همان سندِ تأییدشده انجام می‌شود).

import { vault, getSettings, setSettings, SYSTEMS, nationalCodeIssue } from './lib/vault.js';
import { TAMIN, TAMIN_ACTIONS } from './sites/tamin.js';
import { RESALAT, RESALAT_RANGES, buildInvoiceRequest } from './sites/resalat.js';
import {
  fillLoginForm, readLoginForm, readTaminToken, uploadPick, attachDisk, markCaptcha,
  resalatFillLogin, resalatReadSid, resalatApi,
} from './lib/page-functions.js';
import { getCurrentUser, checkIdentity, collectSnapshot, api as taminCall } from './lib/tamin-collect.js';
import { SECTIONS, SECTION_ORDER, diffSnapshots } from './lib/sections.js';
import { normalizeResalatTransactions } from './lib/statement.js';
import { store } from './lib/store.js';
import { buildResalatXlsx } from './lib/xlsx-write.js';
import * as license from './lib/license.js';

/** گیتِ لایسنس: پیش از اجرای هر اقدامِ سنگین صدا زده می‌شود. */
async function ensureLicensed() {
  const st = await license.getStatus();
  if (!license.isAllowed(st)) {
    const msg = st.state === 'expired'
      ? 'دورهٔ استفاده به پایان رسیده است؛ برای ادامه لایسنس را از بخشِ «لایسنس» فعال کنید.'
      : st.state === 'need_email'
        ? 'برای شروعِ دورهٔ آزمایشی، ایمیل را در بخشِ «لایسنس» ثبت کنید.'
        : st.state === 'device_limit'
          ? 'تعداد دستگاه‌های مجاز پر شده است.'
          : st.state === 'offline'
            ? 'اتصال به سرویسِ لایسنس برقرار نشد؛ اتصالِ اینترنت را بررسی کنید.'
            : 'برای استفاده باید لایسنس فعال باشد (بخشِ «لایسنس»).';
    const err = new Error(msg);
    err.code = 'LICENSE';
    throw err;
  }
  return st;
}

const RUN_KEY = 'run';
const PENDING_KEY = 'pendingLogins';
const UNSEEN_KEY = 'unseenChanges';
const UPLOADS_KEY = 'uploads';
const STATEMENTS_KEY = 'statements';
const ZAMANI_AUTH_KEY = 'zamaniAuth';
const UPLOAD_ACTION = { id: 'upload', title: 'ورود + ارسال لیست بیمه' };

// ───────────── راه‌اندازی ─────────────

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  // فقط صفحه‌های خودِ افزونه (نه content scriptها) به storage.session دسترسی دارند
  chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});
});

chrome.alarms.create('autolock', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async (a) => {
  // status() خودش قفلِ ناشی از بی‌کاری را اعمال می‌کند
  if (a.name === 'autolock') { try { await vault.status(); } catch {} }
});

// اگر service worker وسطِ یک اجرا خوابیده باشد، آن اجرا دیگر ادامه ندارد
(async () => {
  const { [RUN_KEY]: run } = await chrome.storage.session.get(RUN_KEY);
  if (run?.status === 'running') {
    run.status = 'failed';
    run.error = 'اجرا قطع شد (افزونه دوباره راه‌اندازی شد)';
    await chrome.storage.session.set({ [RUN_KEY]: run });
  }
})();

// ───────────── پیام‌ها ─────────────

const isPanel = (sender) => sender.id === chrome.runtime.id && !sender.tab &&
  sender.url?.startsWith(chrome.runtime.getURL('sidepanel/'));

/** فقط صفحهٔ ورودِ واقعیِ تأمین روی https — ضدفیشینگ. */
const isTaminLogin = (sender) => {
  if (sender.id !== chrome.runtime.id || !sender.tab || sender.frameId !== 0) return false;
  try {
    const u = new URL(sender.url);
    return u.protocol === 'https:' && u.hostname === TAMIN.loginHost;
  } catch { return false; }
};

const PANEL_HANDLERS = {
  'vault:status': async () => {
    const settings = await getSettings();
    // توکنِ BackupManager به پنل برنمی‌گردد؛ فقط «تنظیم‌شده یا نه»
    const { backupManagerToken, bankImportKey, ...safe } = settings;
    return { ...(await vault.status()), settings: { ...safe, hasBackupManagerToken: !!backupManagerToken, hasBankImportKey: !!bankImportKey } };
  },
  'vault:setup': ({ master }) => vault.setup(master),
  'vault:unlock': ({ master }) => vault.unlock(master),
  'vault:lock': () => vault.lock(),
  'vault:reset': () => vault.reset(),
  'vault:list': () => vault.list(),
  'vault:upsert': ({ entries }) => vault.upsertMany(entries),
  'vault:update': ({ id, patch }) => vault.update(id, patch),
  'vault:delete': ({ id }) => vault.remove(id),
  'settings:set': ({ patch }) => setSettings(patch),
  'meta': () => ({ systems: SYSTEMS, actions: TAMIN_ACTIONS }),
  'run:start': ({ entryId, action, upload }) => startRun({ entryId, action, upload }),
  'uploads:list': async () => (await chrome.storage.local.get(UPLOADS_KEY))[UPLOADS_KEY] || [],
  'bank:save': ({ statement, meta }) => saveStatement(statement, meta),
  'bank:deliver': ({ file, meta }) => deliverStatement(file, meta),
  'bank:deliverLive': ({ statement, meta }) => deliverLiveStatement(statement, meta),
  'bank:deliverZamani': ({ statement, meta }) => deliverToZamani(statement, meta),
  'bank:list': async () => (await chrome.storage.local.get(STATEMENTS_KEY))[STATEMENTS_KEY] || [],
  'zamani:status': () => zamaniStatus(),
  'zamani:login': ({ url, username, password }) => zamaniLogin(url, username, password),
  'zamani:logout': async () => { await chrome.storage.local.remove(ZAMANI_AUTH_KEY); return { ok: true }; },
  'bank:pending': async () => {
    const { pendingStatement } = await chrome.storage.session.get('pendingStatement');
    if (pendingStatement) await chrome.storage.session.remove('pendingStatement');
    return pendingStatement || null;
  },
  'run:get': async () => (await chrome.storage.session.get(RUN_KEY))[RUN_KEY] || null,
  'run:cancel': () => cancelRun(),
  'data:summary': ({ entryId }) => store.summary(entryId),
  'data:page': ({ entryId, section, offset }) => store.page(entryId, section, offset),
  'changes:seen': () => setUnseen(0),
  'license:status': () => license.getStatus(),
  'license:activate': ({ key, email }) => license.activate(key, email),
  'license:suggestEmail': () => license.suggestedEmail(),
  'license:refresh': () => license.getStatus(),
};

const LOGIN_PAGE_HANDLERS = {
  /** نوارِ روی صفحهٔ ورود: فهرستِ حساب‌ها (بدون رمز) + اگر این زبانه منتظرِ ورودِ خودکار است، همین حالا پر کن. */
  'login:init': async (_, sender) => {
    const pending = await takePending(sender.tab.id);
    if (pending) await fillInto(sender, pending.entryId);
    const st = await vault.status();
    if (!st.unlocked) return { locked: true, provider: st.provider };
    const entries = (await vault.list()).filter((e) => e.system === 'tamin').map(({ id, label }) => ({ id, label }));
    return {
      entries, actions: TAMIN_ACTIONS,
      autoFilled: pending ? { entryId: pending.entryId, label: pending.label } : null,
    };
  },
  /**
   * کاربر روی «ذخیره در گاوصندوق» زد: مقدارهای فعلیِ فرمِ سایت در یک حسابِ موجود (اصلاح) یا حسابِ تازه
   * ذخیره می‌شود. خواندنِ فرم در همان سندِ تأییدشده و بدونِ عبورِ رمز از content script انجام می‌شود.
   */
  'login:saveForm': async ({ entryId, label }, sender) => {
    const target = sender.documentId
      ? { tabId: sender.tab.id, documentIds: [sender.documentId] }
      : { tabId: sender.tab.id, frameIds: [0] };
    const [res] = await chrome.scripting.executeScript({ target, func: readLoginForm, args: [TAMIN.selectors] });
    const form = res?.result;
    if (!form?.ok) throw new Error(form?.error || 'خواندنِ فرم ممکن نشد');
    const saved = entryId
      ? await vault.update(entryId, { username: form.username, password: form.password })
      : (await vault.upsertMany([{ label, system: 'tamin', username: form.username, password: form.password }]),
         { label: String(label || '').trim() });
    const digits = form.username.replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
    return { label: saved.label, warning: nationalCodeIssue(digits) };
  },
  /** کاربر روی نوار «ورود» زد. */
  'login:go': async ({ entryId, action }, sender) => {
    if (!action || action === 'login') {
      await fillInto(sender, entryId);
      return { ok: true };
    }
    const run = await startRun({ entryId, action, loginSender: sender });
    chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => {});
    return { ok: true, runId: run.id };
  },
  'login:failed': async ({ message }, sender) => {
    const run = await getRun();
    if (run?.status === 'running' && run.tabId === sender.tab.id) await failRun(run, 'ورود ناموفق: ' + message);
  },
};

const RESALAT_HANDLERS = {
  'resalat:init': async (_, sender) => {
    const onLogin = new URL(sender.url).hostname === RESALAT.loginHost;
    const st = await vault.status();
    if (!st.unlocked) return { locked: true, provider: st.provider, onLogin };
    const accounts = (await vault.list()).filter((e) => e.system === 'bank').map(({ id, label, username }) => ({ id, label, username }));
    return { onLogin, accounts, ranges: RESALAT_RANGES };
  },
  /** پر کردنِ نام کاربری و رمز روی فرمِ ورودِ رسالت؛ کپچا و «ورود» با خودِ کاربر. */
  'resalat:fillLogin': async ({ entryId }, sender) => {
    const entry = await vault.get(entryId);
    if (entry.system !== 'bank') throw new Error('این حساب مربوط به بانک نیست');
    const target = sender.documentId ? { tabId: sender.tab.id, documentIds: [sender.documentId] } : { tabId: sender.tab.id, frameIds: [0] };
    const [res] = await chrome.scripting.executeScript({ target, func: resalatFillLogin, args: [entry.username, entry.password, RESALAT.selectors] });
    if (!res?.result?.ok) throw new Error(res?.result?.error || 'پر کردنِ فرم ممکن نشد');
    return { hasCaptcha: res.result.hasCaptcha };
  },
  /** یک‌کلیک: صورتحساب را از نشستِ زندهٔ کاربر می‌گیرد. */
  'resalat:fetch': ({ entryId, rangeId, depositNumber }, sender) =>
    resalatFetch(sender.tab.id, entryId, rangeId, depositNumber),
};

/** فقط صفحه‌های واقعیِ رسالت روی https (ورود oauth یا اپِ vbank). */
const isResalat = (sender) => {
  if (sender.id !== chrome.runtime.id || !sender.tab || sender.frameId !== 0) return false;
  try {
    const u = new URL(sender.url);
    return u.protocol === 'https:' && (u.hostname === RESALAT.loginHost || u.hostname === RESALAT.appHost);
  } catch { return false; }
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const table = isPanel(sender) ? PANEL_HANDLERS
    : isTaminLogin(sender) ? LOGIN_PAGE_HANDLERS
      : isResalat(sender) ? RESALAT_HANDLERS : null;
  const handler = table?.[msg?.type];
  if (!handler) return false;
  Promise.resolve()
    .then(() => handler(msg, sender))
    .then((data) => sendResponse({ ok: true, data }))
    .catch((e) => sendResponse({ ok: false, error: e?.message || String(e) }));
  return true;
});

// ───────────── پر کردنِ فرم ورود ─────────────

async function fillInto(sender, entryId) {
  const entry = await vault.get(entryId);
  if (entry.system !== 'tamin') throw new Error('این حساب مربوط به تأمین اجتماعی نیست');
  // documentIds تضمین می‌کند اگر صفحه در این فاصله عوض شده باشد، رمز در سندِ دیگری ریخته نشود
  const target = sender.documentId
    ? { tabId: sender.tab.id, documentIds: [sender.documentId] }
    : { tabId: sender.tab.id, frameIds: [0] };
  const [res] = await chrome.scripting.executeScript({
    target, func: fillLoginForm, args: [entry.username, entry.password, TAMIN.selectors],
  });
  if (!res?.result?.ok) throw new Error(res?.result?.error || 'پر کردنِ فرم ممکن نشد');
}

async function takePending(tabId) {
  const { [PENDING_KEY]: all = {} } = await chrome.storage.session.get(PENDING_KEY);
  const p = all[tabId];
  if (!p) return null;
  delete all[tabId];   // یک‌بار مصرف: اگر رمز غلط بود، حلقهٔ ورودِ تکراری ساخته نشود
  await chrome.storage.session.set({ [PENDING_KEY]: all });
  return Date.now() - p.at < 3 * 60_000 ? p : null;
}

async function setPending(tabId, data) {
  const { [PENDING_KEY]: all = {} } = await chrome.storage.session.get(PENDING_KEY);
  all[tabId] = { ...data, at: Date.now() };
  await chrome.storage.session.set({ [PENDING_KEY]: all });
}

// ───────────── اجرای اقدام‌ها ─────────────

let cancelled = false;

async function getRun() {
  return (await chrome.storage.session.get(RUN_KEY))[RUN_KEY] || null;
}

async function saveRun(run) {
  await chrome.storage.session.set({ [RUN_KEY]: run });
  chrome.runtime.sendMessage({ type: 'run:update', run }).catch(() => {});
}

async function failRun(run, error) {
  run.status = 'failed';
  run.error = error;
  run.finishedAt = Date.now();
  await saveRun(run);
}

async function cancelRun() {
  cancelled = true;
  const run = await getRun();
  if (run?.status === 'running') await failRun(run, 'توسط کاربر لغو شد');
}

async function startRun({ entryId, action, loginSender, upload }) {
  await ensureLicensed();
  const current = await getRun();
  if (current?.status === 'running') throw new Error('یک کار دیگر در حال اجراست');
  const def = TAMIN_ACTIONS.find((a) => a.id === action) || (action === 'upload' && upload ? UPLOAD_ACTION : null);
  if (!def) throw new Error('اقدام نامعتبر است');
  const entry = await vault.get(entryId);
  if (entry.system !== 'tamin') throw new Error('در این نسخه فقط حساب‌های تأمین اجتماعی پشتیبانی می‌شوند');

  cancelled = false;
  const run = {
    id: crypto.randomUUID(),
    entryId, label: entry.label, action, actionTitle: def.title,
    status: 'running', startedAt: Date.now(), log: [], result: null, error: null, tabId: null,
  };
  await saveRun(run);
  // فایل‌های دیسکت فقط در حافظهٔ همین اجرا می‌مانند، نه در storage
  executeRun(run, entry, loginSender, upload).catch((e) => failRun(run, e?.message || String(e)));
  return run;
}

async function executeRun(run, entry, loginSender, upload) {
  const log = async (text) => {
    if (cancelled) throw new Error('توسط کاربر لغو شد');
    run.log.push({ at: Date.now(), text });
    await saveRun(run);
  };

  // ۱) ورود
  if (loginSender) {
    run.tabId = loginSender.tab.id;
    await log('پر کردنِ فرم ورود…');
    await fillInto(loginSender, entry.id);
  } else {
    const tab = await chrome.tabs.create({ url: TAMIN.authorizeUrl, active: true });
    run.tabId = tab.id;
    await setPending(tab.id, { entryId: entry.id, label: entry.label, runId: run.id });
    await log('باز کردنِ صفحهٔ ورود تأمین…');
  }
  await log('منتظرِ ورود به سامانه…');
  await waitForTab(run.tabId, (u) => u.hostname === TAMIN.appHost, 90_000);

  // ۲) توکن و بررسیِ هویت
  await log('ورود انجام شد؛ دریافت توکن…');
  const token = await waitForToken(run.tabId, 45_000);
  const user = await getCurrentUser(run.tabId, token);
  const id = checkIdentity(user, entry.username);
  await log(id.verified
    ? `حساب تأیید شد${id.name ? ': ' + id.name : ''}`
    : '⚠ شناسهٔ حساب در پاسخِ سامانه نبود؛ یکی بودنِ حساب را خودتان بررسی کنید');

  // ۳) همگام‌سازی
  if (run.action === 'sync') run.result = await syncAll(run, entry, token, user, log);
  if (run.action === 'upload') run.result = await uploadList(run, entry, token, upload, log);
  if (cancelled) throw new Error('توسط کاربر لغو شد');
  run.status = 'done';
  run.finishedAt = Date.now();
  run.log.push({ at: Date.now(), text: run.result ? `پایان: ${run.result.summary}` : 'پایان' });
  await saveRun(run);
}

// ───────────── اتصالِ ابری: حساب زمانی ─────────────

async function zamaniStatus() {
  const settings = await getSettings();
  const { [ZAMANI_AUTH_KEY]: auth } = await chrome.storage.local.get(ZAMANI_AUTH_KEY);
  return {
    url: settings.zamaniUrl || '',
    loggedIn: !!auth?.accessToken,
    user: auth?.user ? { username: auth.user.username, displayName: auth.user.displayName } : null,
  };
}

/** ورودِ کاربر به حساب زمانی؛ فقط توکن ذخیره می‌شود، نه رمز. */
async function zamaniLogin(url, username, password) {
  const settings = await getSettings();
  const base = String(url || settings.zamaniUrl || '').trim().replace(/\/+$/, '');
  if (!base) throw new Error('آدرس حساب زمانی وارد نشده است');
  if (!username || !password) throw new Error('نام کاربری و رمز لازم است');
  let resp;
  try {
    resp = await fetch(base + '/api/v1/auth/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
  } catch (e) {
    throw new Error('اتصال به حساب زمانی ممکن نشد — آدرس و روشن بودن سرور را بررسی کنید (' + e.message + ')');
  }
  if (resp.status === 401 || resp.status === 400) throw new Error('نام کاربری یا رمز اشتباه است');
  if (!resp.ok) throw new Error(`ورود ناموفق بود (کد ${resp.status})`);
  const data = await resp.json().catch(() => ({}));
  if (!data.accessToken) throw new Error('پاسخِ سرور توکن نداشت');
  await chrome.storage.local.set({
    [ZAMANI_AUTH_KEY]: {
      url: base, accessToken: data.accessToken, refreshToken: data.refreshToken,
      expiresAtUtc: data.expiresAtUtc, user: data.user, at: Date.now(),
    },
  });
  return { user: data.user ? { username: data.user.username, displayName: data.user.displayName } : null };
}

/** ارسالِ صورتحساب به نرم‌افزار حسابداریِ زمانی (اتصال ابری) با توکنِ ورودِ کاربر. */
async function deliverToZamani(statement, meta) {
  const { [ZAMANI_AUTH_KEY]: auth } = await chrome.storage.local.get(ZAMANI_AUTH_KEY);
  if (!auth?.accessToken || !auth?.url) throw new Error('ابتدا در تنظیمات وارد حساب زمانی شوید');
  const account = statement.accountNumber || meta.accountNumber || '';
  if (!account) throw new Error('شمارهٔ حساب در دادهٔ صورتحساب نیست');
  const digits = String(account).replace(/[^0-9]/g, '');
  const body = {
    BankCode: statement.source === 'resalat-live' ? 'Resalat' : (meta.bank || 'Bank'),
    AccountNumber: account,
    FromDate: statement.totals.first,
    ToDate: statement.totals.last,
    IdempotencyKey: `${statement.source === 'resalat-live' ? 'resalat' : 'bank'}:${digits}:${statement.totals.first}:${statement.totals.last}:${statement.totals.count}`,
    Rows: statement.rows,
  };
  let resp;
  try {
    resp = await fetch(auth.url + '/api/v1/bank-inbox/statements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${auth.accessToken}` },
      body: JSON.stringify(body),
    });
  } catch (e) {
    throw new Error('اتصال به حساب زمانی ممکن نشد — سرور را بررسی کنید (' + e.message + ')');
  }
  if (resp.status === 401) throw new Error('نشستِ حساب زمانی منقضی شده — در تنظیمات دوباره وارد شوید');
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.error || `ثبت در حساب زمانی ناموفق بود (کد ${resp.status})`);
  const statusFa = { Stored: 'ثبت شد', Duplicate: 'قبلاً ثبت شده بود' }[data.status] || data.status || 'ارسال شد';
  await recordStatement({
    at: Date.now(), kind: 'zamani', account, count: statement.totals.count,
    from: statement.totals.first, to: statement.totals.last, label: meta.label || '',
    matched: true, company: auth.user?.displayName || '', result: statusFa,
  });
  return { status: data.status, statusFa };
}

// ───────────── صورتحساب بانکی ─────────────

const digitsOnly = (s) => String(s ?? '').replace(/[^0-9]/g, '');

const resalatSleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function resalatInPage(tabId, func, args = []) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func, args, world: 'MAIN' });
  return res?.result;
}

/** X-Tab-Session-ID را می‌گیرد؛ اگر نبود، تبِ کاربر را به صفحهٔ سپرده می‌برد تا SPA آن را تولید کند. */
async function resalatEnsureSid(tabId) {
  for (let i = 0; i < 8; i++) {
    const sid = await resalatInPage(tabId, resalatReadSid);
    if (sid) return sid;
    await resalatSleep(700);
  }
  // هنوز نیست: به صفحهٔ صورتحساب برو تا SPA درخواستِ /pols/ بزند
  await chrome.tabs.update(tabId, { url: RESALAT.depositPage });
  for (let i = 0; i < 30; i++) {
    await resalatSleep(1000);
    let tab;
    try { tab = await chrome.tabs.get(tabId); } catch { throw new Error('زبانهٔ بانک بسته شد'); }
    if (tab.status !== 'complete') continue;
    const sid = await resalatInPage(tabId, resalatReadSid);
    if (sid) return sid;
  }
  throw new Error('نشستِ بانک آماده نشد — روی صفحهٔ «صورتحساب سپرده» وارد شوید و دوباره تلاش کنید');
}

async function resalatFetch(tabId, entryId, rangeId, depositNumber) {
  await ensureLicensed();
  const host = new URL((await chrome.tabs.get(tabId)).url).hostname;
  if (host !== RESALAT.appHost) throw new Error('اول در اینترنت‌بانک رسالت وارد شوید');
  const range = RESALAT_RANGES.find((r) => r.id === rangeId) || RESALAT_RANGES[0];
  const entry = entryId ? await vault.get(entryId).catch(() => null) : null;

  const sid = await resalatEnsureSid(tabId);

  // انتخابِ سپرده
  if (!depositNumber) {
    const r = await resalatInPage(tabId, resalatApi, [RESALAT.gateway, RESALAT.api.deposits, 'GET', null, sid]);
    if (!r?.ok) throw new Error(`دریافتِ فهرستِ سپرده‌ها ناموفق بود${r?.status ? ' (کد ' + r.status + ')' : ''}`);
    const list = Array.isArray(r.json) ? r.json : (r.json?.result || r.json?.data || []);
    const deposits = list.map((d) => ({
      depositNumber: d.depositNumber, depositName: d.depositName || '', branchName: d.branchName || '', sheba: d.shebaNumber || '',
    })).filter((d) => d.depositNumber);
    if (!deposits.length) throw new Error('هیچ سپرده‌ای در این حساب یافت نشد');
    if (deposits.length > 1) return { chooseDeposit: deposits };   // نوار می‌پرسد
    depositNumber = deposits[0].depositNumber;
  }

  const body = buildInvoiceRequest(depositNumber, range, RESALAT.currency);
  const r = await resalatInPage(tabId, resalatApi, [RESALAT.gateway, RESALAT.api.invoice, 'POST', body, sid]);
  if (!r?.ok) throw new Error(`دریافتِ صورتحساب ناموفق بود${r?.status ? ' (کد ' + r.status + ')' : ''}`);
  const txns = Array.isArray(r.json) ? r.json : (r.json?.result || r.json?.data || []);
  const statement = normalizeResalatTransactions(txns, depositNumber);
  if (!statement.rows.length) throw new Error('در این بازه تراکنشی یافت نشد');

  // نتیجه را برای پنل نگه می‌داریم و پنل را باز می‌کنیم
  await chrome.storage.session.set({ pendingStatement: { statement, label: entry?.label || '', bank: 'resalat', range: range.title } });
  chrome.sidePanel.open({ tabId }).catch(() => {});
  chrome.runtime.sendMessage({ type: 'statement:ready' }).catch(() => {});
  return { ok: true, count: statement.totals.count, from: statement.totals.first, to: statement.totals.last, depositNumber };
}

async function recordStatement(rec) {
  const { [STATEMENTS_KEY]: list = [] } = await chrome.storage.local.get(STATEMENTS_KEY);
  await chrome.storage.local.set({ [STATEMENTS_KEY]: [rec, ...list].slice(0, 200) });
}

/** ذخیرهٔ محلیِ صورتحسابِ یکدست‌شده (برنامهٔ کمکی) — کلید بر پایهٔ ارقامِ شمارهٔ حساب. */
async function saveStatement(statement, meta) {
  const acc = digitsOnly(statement.accountNumber || meta.accountNumber) || 'unknown';
  const key = `bank-${acc}`;
  // نسخه را به شکلِ سازگار با store نگه می‌داریم: یک بخشِ «transactions»
  const snap = {
    v: 1, takenAt: new Date().toISOString(), label: meta.label || '',
    accountNumber: statement.accountNumber, totals: statement.totals,
    sections: { transactions: statement.rows }, errors: {},
  };
  const where = await store.save(key, snap);
  await recordStatement({
    at: Date.now(), kind: 'save', where, account: statement.accountNumber || '',
    count: statement.totals.count, from: statement.totals.first, to: statement.totals.last,
    withdraw: statement.totals.withdraw, deposit: statement.totals.deposit, label: meta.label || '',
  });
  return { where, key };
}

/**
 * ارسالِ فایلِ اصلِ صورتحساب به BackupManagerِ روی سیستمِ کاربر (شناختِ خودکارِ شرکت از شمارهٔ حساب).
 * فایل، ارسال‌شده، خودِ خروجیِ اینترنت‌بانک است؛ BackupManager آن را پردازش می‌کند. هیچ اعتبارنامه‌ای در کار نیست.
 */
async function deliverStatement(file, meta) {
  const settings = await getSettings();
  if (!settings.backupManagerUrl) throw new Error('آدرس BackupManager در تنظیمات وارد نشده است');
  if (!settings.backupManagerToken) throw new Error('توکنِ BackupManager در تنظیمات وارد نشده است');

  const bin = atob(file.b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const form = new FormData();
  form.append('file', new Blob([bytes]), file.name);
  if (meta.chatId) form.append('chatId', meta.chatId);

  const url = settings.backupManagerUrl + '/api/v1/bankimport/agent/identify-import';
  let resp;
  try {
    resp = await fetch(url, { method: 'POST', headers: { 'X-Callback-Token': settings.backupManagerToken }, body: form });
  } catch (e) {
    throw new Error('اتصال به BackupManager ممکن نشد — آدرس و روشن بودنِ آن را بررسی کنید (' + e.message + ')');
  }
  if (resp.status === 401) throw new Error('توکنِ BackupManager پذیرفته نشد');
  if (!resp.ok) throw new Error(`BackupManager خطا داد (کد ${resp.status})`);
  const data = await resp.json().catch(() => ({}));

  await recordStatement({
    at: Date.now(), kind: 'deliver', account: meta.accountNumber || '',
    count: meta.count, from: meta.from, to: meta.to, label: meta.label || '',
    matched: data.matched !== false,
    company: data.companyName || data.company || '',
    bank: data.bankName || '', result: data.status || (data.matched === false ? 'شرکت شناسایی نشد' : 'ارسال شد'),
  });
  return data;
}

/** بایت‌ها → base64 (برای فیلدِ byte[] در JSONِ ingest). */
function bytesToB64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

/**
 * ثبتِ خودکارِ دادهٔ زندهٔ بانک در حسابداری از راهِ ingestِ JSONِ BackupManager.
 * یک اکسلِ هم‌ساختارِ BankHub می‌سازیم (چون BackupManager با نگاشتِ ثابت همان را می‌خواند)
 * و به /api/v1/bankimport/ingest/bank-statement می‌فرستیم. BackupManager شرکت را از شمارهٔ حساب
 * پیدا می‌کند و سند می‌سازد. هیچ اعتبارنامه‌ای در کار نیست.
 */
async function deliverLiveStatement(statement, meta) {
  const settings = await getSettings();
  if (!settings.backupManagerUrl) throw new Error('آدرس BackupManager در تنظیمات وارد نشده است');
  if (!settings.bankImportKey) throw new Error('کلیدِ ثبتِ بانک (X-Api-Key) در تنظیمات وارد نشده است');

  const account = statement.accountNumber || meta.accountNumber || '';
  if (!account) throw new Error('شمارهٔ حساب در دادهٔ صورتحساب نیست');
  const xlsx = buildResalatXlsx(statement, { deposit: account });
  const range = `${statement.totals.first}..${statement.totals.last}`;
  const idem = `resalat:${digitsOnly(account)}:${statement.totals.first}:${statement.totals.last}:${statement.totals.count}`;

  const delivery = {
    BankCode: 'Resalat',
    Account: {
      DepositNumber: account, ShebaNumber: null, DepositName: meta.label || null,
      BranchName: null, CurrencyIsoCode: '364', AccountOwner: meta.label || null,
    },
    RangeDescription: range,
    FetchedAt: new Date().toISOString(),
    IdempotencyKey: idem,
    Payload: {
      TransactionCount: statement.totals.count,
      RawJson: JSON.stringify({ rows: statement.rows }),
      ExcelFileName: `resalat-${digitsOnly(account)}.xlsx`,
      ExcelBytes: bytesToB64(xlsx),   // byte[] در C# از رشتهٔ base64 خوانده می‌شود
    },
  };

  const url = settings.backupManagerUrl + '/api/v1/bankimport/ingest/bank-statement';
  let resp;
  try {
    resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Api-Key': settings.bankImportKey },
      body: JSON.stringify(delivery),
    });
  } catch (e) {
    throw new Error('اتصال به BackupManager ممکن نشد — آدرس و روشن بودنِ آن را بررسی کنید (' + e.message + ')');
  }
  if (resp.status === 401) throw new Error('کلیدِ ثبتِ بانک پذیرفته نشد (X-Api-Key)');
  if (resp.status === 503) throw new Error('سرویسِ ثبت در BackupManager پیکربندی نشده (IngestApiKey)');
  const data = await resp.json().catch(() => ({}));
  // 200 Imported/Duplicate، 202 Unmatched، بقیه خطا
  if (!resp.ok && resp.status !== 202) throw new Error(data.message || `BackupManager خطا داد (کد ${resp.status})`);

  const statusFa = { Imported: 'ثبت شد', Duplicate: 'قبلاً ثبت شده بود', Unmatched: 'شرکت پیدا نشد', Failed: 'ناموفق' }[data.status] || data.status || '';
  await recordStatement({
    at: Date.now(), kind: 'ingest', account, count: statement.totals.count,
    from: statement.totals.first, to: statement.totals.last, label: meta.label || '',
    matched: data.status !== 'Unmatched', result: statusFa,
  });
  return { status: data.status, message: data.message, statusFa };
}

// ───────────── ارسال لیست بیمه ─────────────

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const inPage = async (tabId, func, args = []) =>
  (await chrome.scripting.executeScript({ target: { tabId }, func, args }))[0]?.result;
const faEn = (s) => String(s ?? '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));

/** لیست‌های ثبت‌شدهٔ یک مقصد (کارگاه + ردیف پیمان)، تازه‌ترین اول. */
async function listHistory(tabId, token, t) {
  const [r] = await taminCall(tabId, token, [{
    id: 'h',
    url: `${TAMIN.api.celist}/workshop-history`,
    paged: true,
    filter: [
      { property: 'workshop.code', value: t.code, operator: 'EQ' },
      ...(t.contract ? [{ property: 'workshop.contractNumber', value: t.contract, operator: 'EQ' }] : []),
    ],
    sort: [{ property: 'statusModificationTime', direction: 'DESC' }],
  }]);
  if (!r.ok) throw new Error(`دریافتِ لیست‌های قبلی ناموفق بود (کد ${r.status})`);
  return r.items.map((l) => SECTIONS.lists.normalize(l));
}

const samePeriod = (l, up) => l.year % 100 === up.yy && l.month === up.mm;
// لیستی که سازمان رد کرده یا کارفرما تأییدش نکرده، مانعِ ارسالِ دوباره نیست
const blocksResend = (l) => !/غیرقابل ارسال|عدم تایید/.test(l.status);

/**
 * صفحهٔ «ارسال لیست» را آماده می‌کند: کارگاه را انتخاب و دو فایل را پیوست می‌کند، فیلدِ کد امنیتی را
 * برجسته می‌کند و منتظر می‌ماند تا کاربر خودش «ثبت درخواست» را بزند؛ بعد لیستِ تازه را از سامانه می‌خواند.
 */
async function uploadList(run, entry, token, up, log) {
  const t = up.target;
  const where = `کارگاه ${t.code} / شعبه ${t.branchCode}${t.contract ? ' / ردیف پیمان ' + t.contract : ' (اصلی)'}`;
  await log(`${where} — دورهٔ ${up.period} — ${up.workerCount.toLocaleString('fa-IR')} نفر`);

  // ۱) بررسیِ زندهٔ تکراری بودن (پنل از روی دادهٔ ذخیره‌شده هم بررسی کرده، ولی ممکن است قدیمی باشد)
  const before = await listHistory(run.tabId, token, t);
  const dup = before.find((l) => samePeriod(l, up) && blocksResend(l));
  if (dup && !up.allowDuplicate) {
    throw new Error(`برای دورهٔ ${up.period} از قبل لیستی با وضعیتِ «${dup.status}» ثبت شده است. ` +
      'اگر ارسالِ دوباره عمدی است، در پنل تأیید کنید.');
  }
  const baseline = new Set(before.map((l) => l.id));

  // ۲) صفحهٔ ارسال لیست و انتخابِ کارگاه
  await log('باز کردنِ صفحهٔ «ارسال لیست بیمه» و انتخابِ کارگاه…');
  let opened = false, misses = 0;
  for (const deadline = Date.now() + 60_000; ;) {
    if (cancelled) throw new Error('توسط کاربر لغو شد');
    if (Date.now() > deadline) throw new Error('صفحهٔ ارسالِ لیست یا فهرستِ کارگاه‌ها در زمانِ مقرر بالا نیامد');
    const r = await inPage(run.tabId, uploadPick, [{ ...t, knownContracts: up.knownContracts || [] }, opened]);
    if (r?.stage === 'selected') { await log('کارگاه انتخاب شد: ' + r.cells.filter(Boolean).slice(0, 4).join(' | ')); break; }
    if (r?.stage === 'picker-opened') opened = true;
    if (r?.stage === 'no-match' && ++misses >= 4) {
      throw new Error(`ردیفِ «${where}» در فهرستِ کارگاه‌های سایت پیدا نشد. ردیف‌های موجود: ` +
        r.rows.map((c) => c.filter(Boolean).join(' | ')).join(' ؛ '));
    }
    await sleep(1500);
  }

  // ۳) پیوستِ فایل‌ها و راستی‌آزمایی که فرم برای همان کارگاه است
  let attached = null;
  for (const deadline = Date.now() + 30_000; !attached; ) {
    if (cancelled) throw new Error('توسط کاربر لغو شد');
    if (Date.now() > deadline) throw new Error('فیلدهای پیوستِ فایل در صفحه ظاهر نشد');
    const r = await inPage(run.tabId, attachDisk, [up.kar, up.wor]);
    if (r?.ok) attached = r;
    else await sleep(1500);
  }
  const ro = attached.readonly.map(faEn);
  if (ro.length && !ro.some((v) => v.includes(t.code))) {
    throw new Error(`فرمِ سایت برای کارگاهِ دیگری است (${ro.join('، ')}). ` +
      'چیزی ارسال نشده؛ پیش از هر کاری فایل‌های پیوست‌شده را از فرم بردارید یا صفحه را ببندید.');
  }
  await log(attached.byOrder
    ? 'فایل‌ها پیوست شد (به ترتیبِ فیلدها: اول کارگاه، دوم بیمه‌شدگان) — لطفاً در صفحه بررسی کنید'
    : 'فایل‌ها پیوست شد: DSKKAR ← کارگاه، DSKWOR ← بیمه‌شدگان');
  await inPage(run.tabId, markCaptcha);
  await chrome.tabs.update(run.tabId, { active: true });
  await log('⏳ کد امنیتی را در صفحه وارد و «ثبت درخواست» را بزنید؛ افزونه منتظرِ ثبت است…');

  // ۴) منتظرِ ثبتِ کاربر: لیستِ تازهٔ همین دوره در سامانه
  for (const deadline = Date.now() + 20 * 60_000; ; await sleep(5000)) {
    if (cancelled) throw new Error('توسط کاربر لغو شد');
    if (Date.now() > deadline) throw new Error('در ۲۰ دقیقه لیستِ تازه‌ای ثبت نشد — اگر ارسال کرده‌اید، «همگام‌سازی کامل» را بزنید');
    try { await chrome.tabs.get(run.tabId); } catch { throw new Error('زبانهٔ سامانه بسته شد'); }
    const now = await listHistory(run.tabId, token, t);
    const fresh = now.find((l) => !baseline.has(l.id) && samePeriod(l, up)) || now.find((l) => !baseline.has(l.id));
    if (!fresh) continue;

    const record = {
      at: Date.now(), entryId: entry.id, label: entry.label,
      code: t.code, branchCode: t.branchCode, contract: t.contract || '',
      period: up.period, workerCount: up.workerCount,
      listId: fresh.id, status: fresh.status, traceCode: fresh.traceCode,
    };
    const { [UPLOADS_KEY]: history = [] } = await chrome.storage.local.get(UPLOADS_KEY);
    await chrome.storage.local.set({ [UPLOADS_KEY]: [record, ...history].slice(0, 100) });
    chrome.notifications.create({
      type: 'basic', iconUrl: 'icons/icon-128.png', priority: 1,
      title: `لیست بیمهٔ ${up.period} ثبت شد`,
      message: `${entry.label} — کارگاه ${t.code}: ${fresh.status}${fresh.traceCode ? ' — کد رهگیری ' + fresh.traceCode : ''}`,
    });
    return { kind: 'upload', summary: `لیست ${up.period} ثبت شد — وضعیت: ${fresh.status}`, record };
  }
}

// ───────────── همگام‌سازیِ کامل ─────────────

/** جمع‌آوری ← مقایسه با نسخهٔ قبل ← ذخیره ← اعلان. */
async function syncAll(run, entry, token, user, log) {
  const snap = await collectSnapshot(run.tabId, token, {
    name: [user?.firstName, user?.lastName].filter(Boolean).join(' '),
  }, log);
  snap.label = entry.label;

  await log('مقایسه با همگام‌سازیِ قبلی…');
  const diffable = SECTION_ORDER.filter((n) => SECTIONS[n].diff);
  const prev = await store.sections(entry.id, diffable);
  const changes = prev ? diffSnapshots(prev, snap) : [];

  await log('ذخیرهٔ داده‌ها…');
  const where = await store.save(entry.id, snap);

  const counts = Object.fromEntries(SECTION_ORDER.map((n) => [n, snap.sections[n].length]));
  const errors = snap.errors;
  const failedCount = Object.keys(errors).length;
  if (changes.length) await notifyChanges(entry.label, changes);

  return {
    kind: 'sync',
    first: !prev,
    where,
    counts,
    errors,
    changes: changes.slice(0, 200),
    changeCount: changes.length,
    summary: (prev ? `${changes.length.toLocaleString('fa-IR')} تغییر` : 'اولین همگام‌سازی') +
      (failedCount ? ` — ${failedCount.toLocaleString('fa-IR')} بخش ناموفق` : ''),
  };
}

async function setUnseen(n) {
  await chrome.storage.local.set({ [UNSEEN_KEY]: n });
  await chrome.action.setBadgeText({ text: n ? (n > 99 ? '99+' : n.toLocaleString('fa-IR')) : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#B50000' });
}

async function notifyChanges(label, changes) {
  const { [UNSEEN_KEY]: unseen = 0 } = await chrome.storage.local.get(UNSEEN_KEY);
  await setUnseen(unseen + changes.length);
  chrome.notifications.create({
    type: 'list',
    iconUrl: 'icons/icon-128.png',
    title: `${label}: ${changes.length.toLocaleString('fa-IR')} تغییر در تأمین اجتماعی`,
    message: changes[0].text,
    items: changes.slice(0, 5).map((c) => ({ title: SECTIONS[c.section].title, message: c.text })),
    priority: 1,
  });
}

chrome.notifications.onClicked.addListener(async (id) => {
  chrome.notifications.clear(id);
  const [win] = await chrome.windows.getAll({ windowTypes: ['normal'] });
  if (win) chrome.sidePanel.open({ windowId: win.id }).catch(() => {});
});

/** منتظر می‌ماند تا زبانه به آدرسِ مطلوب برسد. پرسشِ هر ثانیه service worker را هم بیدار نگه می‌دارد. */
function waitForTab(tabId, predicate, timeoutMs) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeoutMs;
    const timer = setInterval(async () => {
      if (cancelled) { clearInterval(timer); return reject(new Error('توسط کاربر لغو شد')); }
      let tab;
      try { tab = await chrome.tabs.get(tabId); } catch {
        clearInterval(timer); return reject(new Error('زبانهٔ سامانه بسته شد'));
      }
      try {
        if (tab.status === 'complete' && tab.url && predicate(new URL(tab.url))) {
          clearInterval(timer); return resolve(tab);
        }
      } catch {}
      if (Date.now() > deadline) {
        clearInterval(timer);
        reject(new Error('ورود در زمانِ مقرر انجام نشد — نام کاربری/رمز یا دسترسی به سامانه را بررسی کنید'));
      }
    }, 1000);
  });
}

async function waitForToken(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (cancelled) throw new Error('توسط کاربر لغو شد');
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: readTaminToken });
      const t = r?.result;
      // روی صفحهٔ callback، localStorage ممکن است هنوز توکنِ قبلی را داشته باشد — صبر تا تبادل تمام شود
      if (t?.token && (t.fromHash || t.path !== '/auth/access')) return t.token;
    } catch {}
    await new Promise((r) => setTimeout(r, 1000));
  }
  throw new Error('توکنِ دسترسی از صفحهٔ تأمین خوانده نشد');
}
