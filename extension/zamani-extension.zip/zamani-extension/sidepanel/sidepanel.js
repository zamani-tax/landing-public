import { parseCredentialFile, unzipAll } from '../lib/import.js';
import { identifyDisk, summarizeDisk } from '../lib/dbf.js';
import { nationalCodeIssue } from '../lib/vault.js';
import { SECTIONS, SECTION_ORDER, faDate } from '../lib/sections.js';
import { parseStatement } from '../lib/statement.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fa = (n) => Number(n).toLocaleString('fa-IR');

async function call(type, data = {}) {
  const res = await chrome.runtime.sendMessage({ type, ...data });
  if (!res?.ok) throw new Error(res?.error || 'خطای نامشخص');
  return res.data;
}

let toastTimer;
function toast(text, isError = false) {
  const t = $('toast');
  t.textContent = text;
  t.className = 'toast' + (isError ? ' error' : '');
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, isError ? 7000 : 3500);
}

/** اجرای یک کارِ UI با قفل کردنِ دکمه و نمایشِ خطا. */
async function guard(btn, fn) {
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { if (btn) btn.disabled = false; }
}

let meta = { systems: {}, actions: [] };
let entries = [];

// ───────────── تب‌های اصلی ─────────────

const TABS = [
  { id: 'insurance', title: 'بیمه', panel: 'tab-insurance', module: 'insurance' },
  { id: 'bank', title: 'بانک', panel: 'tab-bank', module: 'bank' },
  { id: 'tax', title: 'مالیات', panel: 'tab-tax', module: 'tax' },
  { id: 'settings', title: 'تنظیمات', panel: 'tab-settings' },
];
// نگاشتِ دامنه → ماژول، برای فعال‌سازیِ خودکارِ تب بر اساسِ صفحه‌ای که کاربر باز کرده
const SITE_MODULE = [
  { re: /(^|\.)tamin\.ir$/i, module: 'insurance' },
  { re: /(^|\.)rqb\.ir$/i, module: 'bank' },            // رسالت
  { re: /(^|\.)bpi\.ir$/i, module: 'bank' },            // پاسارگاد
  { re: /(^|\.)tourismbank\.ir$/i, module: 'bank' },    // گردشگری
  { re: /(^|\.)tax\.gov\.ir$/i, module: 'tax' },
];
let activeTab = 'insurance';
let userPickedTab = false;   // اگر کاربر خودش تبی را انتخاب کرده، خودکار عوضش نکن
let enabledModules = { insurance: true, bank: true, tax: false };

function moduleForUrl(url) {
  try { const h = new URL(url).hostname; return SITE_MODULE.find((s) => s.re.test(h))?.module || null; } catch { return null; }
}

/** تبِ متناظر با صفحهٔ فعالِ مرورگر را (اگر ماژولش روشن باشد) خودکار انتخاب می‌کند. */
async function autoSelectTabForActivePage(force = false) {
  if (userPickedTab && !force) return;
  let tabs;
  try { tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true }); } catch { return; }
  const mod = moduleForUrl(tabs?.[0]?.url || '');
  if (mod && enabledModules[mod] && activeTab !== mod) { activeTab = mod; renderTabs(); }
}

// وقتی کاربر بین زبانه‌های مرورگر جابه‌جا می‌شود یا آدرسِ زبانهٔ فعال عوض می‌شود
chrome.tabs.onActivated.addListener(() => { userPickedTab = false; autoSelectTabForActivePage(); });
chrome.tabs.onUpdated.addListener((_id, info, tab) => {
  if (info.url && tab.active) { userPickedTab = false; autoSelectTabForActivePage(); }
});

function renderTabs() {
  const visible = TABS.filter((t) => !t.module || enabledModules[t.module]);
  if (!visible.some((t) => t.id === activeTab)) activeTab = visible[0]?.id || 'settings';
  $('tabBar').innerHTML = visible
    .map((t) => `<button data-tab="${t.id}" class="${t.id === activeTab ? 'active' : ''}">${esc(t.title)}</button>`)
    .join('');
  for (const t of TABS) { const el = document.getElementById(t.panel); if (el) el.hidden = t.id !== activeTab; }
}

$('tabBar').onclick = (ev) => {
  const id = ev.target.dataset?.tab;
  if (!id) return;
  activeTab = id;
  userPickedTab = true;   // انتخابِ دستی بر انتخابِ خودکار مقدم است
  renderTabs();
};

// ───────────── لایسنس ─────────────
let licenseStatus = null;
const STATE_FA = {
  trial: 'دورهٔ آزمایشی', pro: 'لایسنسِ فعال', expired: 'به پایان رسیده',
  need_email: 'ثبت‌نشده', none: 'ثبت‌نشده', offline: 'آفلاین', device_limit: 'محدودیتِ دستگاه',
};

async function updateLicense(vaultMain) {
  try { licenseStatus = await call('license:status'); }
  catch (e) { licenseStatus = { state: 'offline', error: e.message }; }
  renderLicense(vaultMain);
}

function renderLicense(vaultMain) {
  const s = licenseStatus || { state: 'offline' };
  // بعد از انقضا: «فقط‌خواندنی» — دادهٔ ذخیره‌شده در دسترس می‌ماند، فقط اقدام‌های زنده قفل می‌شوند.
  const readOnly = s.state === 'expired' || s.state === 'device_limit';
  // هنوز راه‌اندازی نشده (اصلاً توکنی نگرفته) → دروازهٔ ورودِ ایمیل.
  const needSetup = s.state === 'need_email' || s.state === 'none' || s.state === 'offline';

  // نوارِ بالای پنل
  const bar = $('licenseBar');
  if (s.state === 'trial') {
    bar.hidden = false;
    bar.className = 'license-bar' + (s.daysLeft <= 3 ? ' warn' : '');
    bar.textContent = `دورهٔ آزمایشی — ${fa(s.daysLeft)} روز باقی مانده`;
  } else if (readOnly) {
    bar.hidden = false;
    bar.className = 'license-bar warn';
    bar.textContent = s.state === 'device_limit'
      ? 'این لایسنس روی دستگاهِ دیگری فعال است — حالتِ فقط‌خواندنی. برای انتقال با پشتیبانی تماس بگیرید.'
      : 'دورهٔ استفاده به پایان رسید — حالتِ فقط‌خواندنی. برای ادامه: تنظیمات ← لایسنس.';
  } else {
    bar.hidden = true;
  }

  // کارتِ لایسنس در تنظیمات
  renderLicenseCard(s);

  // دروازه فقط برای «هنوز راه‌اندازی‌نشده»؛ در حالتِ فقط‌خواندنی main باز می‌ماند.
  const gate = $('licenseView');
  if (vaultMain && needSetup) {
    fillGate(s);
    gate.hidden = false;
    $('mainView').hidden = true;
  } else {
    gate.hidden = true;
  }
}

let gatePrefilled = false;
function fillGate(s) {
  // فقط برای حالت‌های «هنوز فعال‌نشده» صدا زده می‌شود (need_email/none/offline).
  $('licenseTitle').textContent = 'فعال‌سازی دستیار حسابداری زمانی';
  $('licenseMsg').textContent = s.state === 'offline'
    ? (s.error || 'اتصال به سرویسِ لایسنس برقرار نشد؛ اینترنت را بررسی کنید و «بررسی مجدد» را بزنید.')
    : 'برای استفاده، ایمیل و کلیدِ لایسنس را وارد کنید. کلیدِ دورهٔ آزمایشیِ رایگان (۱۴ روزه) یا اشتراک را از پشتیبانی در تلگرام بگیرید.';
  // یک‌بار ایمیلِ مرورگر را برای راحتی پیش‌پر کن.
  if (!gatePrefilled) {
    gatePrefilled = true;
    call('license:suggestEmail').then((email) => {
      if (email && !$('licenseKeyForm').email.value) $('licenseKeyForm').email.value = email;
    }).catch(() => {});
  }
}

function renderLicenseCard(s) {
  const line = $('licenseStatusLine');
  const facts = $('licenseFacts');
  const label = STATE_FA[s.state] || s.state;
  if (s.state === 'trial' || s.state === 'pro') {
    line.textContent = 'وضعیت: ' + label;
    const rows = [['حالت', label]];
    if (s.email) rows.push(['ایمیل', s.email]);
    if (s.daysLeft != null) rows.push(['روزهای باقی‌مانده', fa(s.daysLeft) + ' روز']);
    if (s.exp) rows.push(['تاریخ انقضا', faDate(new Date(s.exp * 1000).toISOString())]);
    facts.innerHTML = rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('');
    facts.hidden = false;
  } else {
    line.textContent = 'وضعیت: ' + label + (s.error ? ' — ' + s.error : '');
    facts.hidden = true;
  }
}

// فعال‌سازی با کلیدِ لایسنس (دروازه: با ایمیل؛ تنظیمات: ایمیل از کش)
async function submitLicenseKey(ev) {
  ev.preventDefault();
  const key = ev.target.key.value.trim();
  const email = ev.target.email ? ev.target.email.value.trim() : undefined;
  try {
    const s = await call('license:activate', { key, email });
    if (s.state === 'pro' || s.state === 'trial') {
      toast(s.state === 'trial' ? 'دورهٔ آزمایشی فعال شد' : 'لایسنس فعال شد');
      ev.target.reset();
    } else toast(s.error || 'فعال‌سازی ناموفق بود', true);
    await refresh();
  } catch (e) { toast(e.message, true); }
}
$('licenseKeyForm').addEventListener('submit', submitLicenseKey);
$('licenseKeyForm2').addEventListener('submit', submitLicenseKey);
$('licenseRefreshBtn').addEventListener('click', async () => {
  toast('در حال بررسی…');
  await refresh();
});

// ───────────── وضعیت و نماها ─────────────

async function refresh() {
  const st = await call('vault:status');
  $('providerBadge').textContent = st.provider === 'native' ? 'برنامهٔ کمکی ویندوز' : 'گاوصندوق داخلی';
  for (const r of document.querySelectorAll('#settingsForm [name=provider]')) r.checked = r.value === st.settings.provider;
  $('settingsForm').autoLockMinutes.value = st.settings.autoLockMinutes;
  $('settingsForm').backupManagerUrl.value = st.settings.backupManagerUrl || '';
  $('settingsForm').backupManagerToken.placeholder = st.settings.hasBackupManagerToken ? '••••• (تنظیم شده)' : 'خالی = تغییر نکند';
  $('settingsForm').bankImportKey.placeholder = st.settings.hasBankImportKey ? '••••• (تنظیم شده)' : 'خالی = تغییر نکند';
  bankDeliverReady = !!(st.settings.backupManagerUrl && st.settings.hasBackupManagerToken);
  bankIngestReady = !!(st.settings.backupManagerUrl && st.settings.hasBankImportKey);
  if (typeof updateStmtButtons === 'function') updateStmtButtons();

  const view = st.provider === 'native'
    ? (st.unlocked ? 'main' : 'nativeDown')
    : (!st.exists ? 'setup' : st.unlocked ? 'main' : 'unlock');
  $('setupView').hidden = view !== 'setup';
  $('unlockView').hidden = view !== 'unlock';
  $('nativeDownView').hidden = view !== 'nativeDown';
  $('mainView').hidden = view !== 'main';
  $('lockBtn').hidden = !(view === 'main' && st.provider === 'local');
  if (view === 'nativeDown') $('nativeErr').textContent = st.error || '';
  if (view === 'unlock') $('unlockForm').m.focus();
  enabledModules = st.settings.modules || enabledModules;
  const sf = $('settingsForm');
  sf['mod-insurance'].checked = !!enabledModules.insurance;
  sf['mod-bank'].checked = !!enabledModules.bank;
  sf['mod-tax'].checked = !!enabledModules.tax;
  if (view === 'main') { renderTabs(); await loadEntries(); }
  await renderSteps({ vault: st.exists });
  await updateLicense(view === 'main');
}

// ───────────── راهنمای راه‌اندازی ─────────────

const ONBOARD = 'onboarding';

/** هر گام وقتی یک بار انجام شد، انجام‌شده می‌ماند (حتی اگر بعداً گاوصندوق قفل شود). */
async function renderSteps(patch = {}) {
  const { [ONBOARD]: saved = {} } = await chrome.storage.local.get(ONBOARD);
  const state = { ...saved };
  for (const [k, v] of Object.entries(patch)) if (v) state[k] = true;
  if (JSON.stringify(state) !== JSON.stringify(saved)) await chrome.storage.local.set({ [ONBOARD]: state });

  const order = ['vault', 'account', 'login'];
  const current = order.find((k) => !state[k]);
  $('stepsCard').hidden = !current;
  for (const li of document.querySelectorAll('.steps li')) {
    li.classList.toggle('done', !!state[li.dataset.step]);
    li.classList.toggle('current', li.dataset.step === current);
  }
}

async function loadEntries() {
  entries = await call('vault:list');
  $('noEntries').hidden = entries.length > 0;
  $('entryList').innerHTML = entries.map((e) => `
    <li>
      <span class="chip">${esc(meta.systems[e.system] || e.system)}</span>
      <span class="name">${esc(e.label)}<small>${esc(e.username)}</small></span>
      <button class="icon" data-edit="${esc(e.id)}" title="ویرایش">✎</button>
      <button class="icon danger" data-del="${esc(e.id)}" title="حذف">×</button>
    </li>`).join('');

  const tamin = entries.filter((e) => e.system === 'tamin');
  const prev = $('runEntry').value;
  $('runEntry').innerHTML = tamin.length
    ? tamin.map((e) => `<option value="${esc(e.id)}">${esc(e.label)}</option>`).join('')
    : '<option value="">— حساب تأمینی ثبت نشده —</option>';
  if (tamin.some((e) => e.id === prev)) $('runEntry').value = prev;
  for (const b of $('actionButtons').children) b.disabled = !tamin.length;
  await renderSteps({ account: tamin.length > 0 });
}

// ───────────── گاوصندوق ─────────────

$('setupForm').onsubmit = (ev) => {
  ev.preventDefault();
  const f = ev.target;
  if (f.m1.value !== f.m2.value) return toast('دو رمز یکسان نیستند', true);
  guard(f.querySelector('button'), async () => {
    await call('vault:setup', { master: f.m1.value });
    f.reset();
    toast('گاوصندوق ساخته شد');
    await refresh();
  });
};

$('unlockForm').onsubmit = (ev) => {
  ev.preventDefault();
  const f = ev.target;
  guard(f.querySelector('button'), async () => {
    await call('vault:unlock', { master: f.m.value });
    f.reset();
    await refresh();
  });
};

$('forgotBtn').onclick = () => {
  if (!confirm('همهٔ حساب‌های ذخیره‌شده در گاوصندوق داخلی پاک می‌شوند و باید دوباره وارد شوند. ادامه می‌دهید؟')) return;
  guard(null, async () => { await call('vault:reset'); await refresh(); });
};

$('lockBtn').onclick = () => guard($('lockBtn'), async () => { await call('vault:lock'); await refresh(); });
$('nativeRetry').onclick = () => guard($('nativeRetry'), refresh);

$('entryList').onclick = (ev) => {
  if (ev.target.dataset?.edit) return startEdit(ev.target.dataset.edit);
  const id = ev.target.dataset?.del;
  if (!id) return;
  const e = entries.find((x) => x.id === id);
  if (!confirm(`حساب «${e?.label}» حذف شود؟`)) return;
  guard(ev.target, async () => { await call('vault:delete', { id }); await loadEntries(); });
};

// ───────────── افزودن / ویرایشِ حساب ─────────────

let editingId = null;
const latinDigits = (s) => String(s).replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).trim();

/** هشدارِ کد ملی زیرِ فیلدِ نام کاربری (فقط برای تأمین). */
function usernameIssue() {
  const f = $('addForm');
  return f.system.value === 'tamin' && f.username.value.trim() ? nationalCodeIssue(latinDigits(f.username.value)) : null;
}
function updateHint() {
  const issue = usernameIssue();
  $('usernameHint').hidden = !issue;
  $('usernameHint').textContent = issue ? '⚠ ' + issue : '';
}
$('addForm').username.oninput = updateHint;
$('addForm').system.onchange = updateHint;

function startEdit(id) {
  const e = entries.find((x) => x.id === id);
  if (!e) return;
  editingId = id;
  const f = $('addForm');
  f.label.value = e.label;
  f.system.value = e.system;
  f.username.value = e.username;
  f.password.value = '';
  f.password.required = false;
  f.password.placeholder = 'خالی = رمز تغییر نکند';
  f.note.value = e.note || '';
  $('formTitle').textContent = `ویرایش «${e.label}»`;
  $('formSubmit').textContent = 'ذخیرهٔ تغییرات';
  $('formCancel').hidden = false;
  $('formBox').open = true;
  updateHint();
  $('formBox').scrollIntoView({ behavior: 'smooth', block: 'start' });
  f.username.focus();
}

function endEdit() {
  editingId = null;
  const f = $('addForm');
  f.reset();
  f.password.required = true;
  f.password.placeholder = '';
  $('formTitle').textContent = 'افزودن دستی';
  $('formSubmit').textContent = 'افزودن';
  $('formCancel').hidden = true;
  updateHint();
}
$('formCancel').onclick = endEdit;

$('addForm').onsubmit = (ev) => {
  ev.preventDefault();
  const f = ev.target;
  const issue = usernameIssue();
  if (issue && !confirm(`${issue}\n\nبا همین نام کاربری ذخیره شود؟`)) return f.username.focus();
  const entry = Object.fromEntries(new FormData(f));
  guard($('formSubmit'), async () => {
    if (editingId) {
      await call('vault:update', { id: editingId, patch: entry });
      toast(`«${entry.label}» به‌روز شد`);
      endEdit();
      $('formBox').open = false;
    } else {
      const r = await call('vault:upsert', { entries: [entry] });
      f.reset();
      toast(r.updated ? 'حساب به‌روز شد' : 'حساب اضافه شد');
    }
    await loadEntries();
  });
};

// ───────────── ورود از فایل ─────────────

let pendingImport = null;

$('importFile').onchange = async (ev) => {
  const file = ev.target.files[0];
  $('importPreview').hidden = true;
  pendingImport = null;
  if (!file) return;
  try {
    const { entries: rows, errors } = await parseCredentialFile(file);
    pendingImport = rows;
    const bySys = {};
    for (const r of rows) bySys[r.system] = (bySys[r.system] || 0) + 1;
    $('importInfo').textContent = `${fa(rows.length)} حساب خوانده شد: ` +
      Object.entries(bySys).map(([s, n]) => `${meta.systems[s] || s} ${fa(n)}`).join('، ');
    $('importErrors').innerHTML = errors.map((e) => `<li>${esc(e)}</li>`).join('');
    $('importConfirm').disabled = !rows.length;
    $('importPreview').hidden = false;
  } catch (e) {
    toast(e.message, true);
  }
};

$('importConfirm').onclick = () => guard($('importConfirm'), async () => {
  const r = await call('vault:upsert', { entries: pendingImport });
  pendingImport = null;
  $('importFile').value = '';
  $('importPreview').hidden = true;
  toast(`${fa(r.added)} حساب اضافه و ${fa(r.updated)} حساب به‌روز شد. اکنون فایل اکسل اصلی را از سیستم پاک کنید.`);
  await loadEntries();
});

// ───────────── تنظیمات ─────────────

$('settingsForm').onsubmit = (ev) => {
  ev.preventDefault();
  const f = ev.target;
  guard(f.querySelector('button'), async () => {
    const patch = {
      provider: f.provider.value,
      autoLockMinutes: f.autoLockMinutes.value,
      backupManagerUrl: f.backupManagerUrl.value,
      modules: {
        insurance: f['mod-insurance'].checked,
        bank: f['mod-bank'].checked,
        tax: f['mod-tax'].checked,
      },
    };
    // توکن‌ها فقط وقتی فرستاده می‌شوند که کاربر مقداری تایپ کرده باشد (خالی = بدون تغییر)
    if (f.backupManagerToken.value) patch.backupManagerToken = f.backupManagerToken.value;
    if (f.bankImportKey.value) patch.bankImportKey = f.bankImportKey.value;
    // اجازهٔ دسترسی به مقصد (باید در پاسخ به کلیکِ کاربر گرفته شود)
    if (patch.backupManagerUrl) await ensureOrigin(patch.backupManagerUrl);
    await call('settings:set', { patch });
    f.backupManagerToken.value = '';
    f.bankImportKey.value = '';
    toast('تنظیمات ذخیره شد');
    await refresh();
  });
};

/** اجازهٔ host_permission برای یک مقصد را در صورت نبودن می‌گیرد (نیازمندِ user gesture). */
async function ensureOrigin(url) {
  let origin;
  // الگوی مجوز پورت نمی‌پذیرد؛ فقط پروتکل + میزبان (پورت‌نامحور)
  try { const u = new URL(url); origin = `${u.protocol}//${u.hostname}/*`; } catch { throw new Error('آدرس نامعتبر است'); }
  const has = await chrome.permissions.contains({ origins: [origin] });
  if (has) return;
  const granted = await chrome.permissions.request({ origins: [origin] });
  if (!granted) throw new Error('اجازهٔ دسترسی به این آدرس داده نشد');
}

// ───────────── اتصال ابری: حساب زمانی ─────────────

let zamaniLoggedIn = false;

async function loadZamani() {
  const st = await call('zamani:status');
  $('zamaniUrl').value = st.url || '';
  $('zamaniLoggedIn').hidden = !st.loggedIn;
  $('zamaniLoggedOut').hidden = st.loggedIn;
  if (st.loggedIn) $('zamaniWho').textContent = `متصل به حساب زمانی: ${st.user?.displayName || st.user?.username || ''}`;
  zamaniLoggedIn = st.loggedIn;
  if (typeof updateStmtButtons === 'function') updateStmtButtons();
}

$('zamaniLoginBtn').onclick = () => guard($('zamaniLoginBtn'), async () => {
  const url = $('zamaniUrl').value.trim();
  const username = $('zamaniUser').value.trim();
  const password = $('zamaniPass').value;
  if (!url) throw new Error('آدرس سرور را وارد کنید');
  if (!username || !password) throw new Error('نام کاربری و رمز را وارد کنید');
  await ensureOrigin(url);
  await call('settings:set', { patch: { zamaniUrl: url } });
  const r = await call('zamani:login', { url, username, password });
  $('zamaniPass').value = '';
  $('zamaniUser').value = '';
  toast(`متصل شد: ${r.user?.displayName || r.user?.username || ''}`);
  await loadZamani();
});

$('zamaniLogoutBtn').onclick = () => guard($('zamaniLogoutBtn'), async () => {
  await call('zamani:logout');
  await loadZamani();
});

// ───────────── اجرای اقدام‌ها ─────────────

function renderActions() {
  // «همگام‌سازی کامل» دکمهٔ اصلی است، «فقط ورود» فرعی
  $('actionButtons').innerHTML = [...meta.actions]
    .sort((a, b) => (a.id === 'sync' ? -1 : b.id === 'sync' ? 1 : 0))
    .map((a) => `<button data-action="${esc(a.id)}" class="${a.id === 'login' ? 'ghost' : ''}">${esc(a.title.replace('ورود + ', ''))}</button>`)
    .join('');
}

$('actionButtons').onclick = (ev) => {
  const action = ev.target.dataset?.action;
  if (!action || !$('runEntry').value) return;
  guard(null, async () => {
    const run = await call('run:start', { entryId: $('runEntry').value, action });
    renderRun(run);
  });
};

$('runEntry').onchange = () => { loadData($('runEntry').value); renderDisk(); };
$('cancelBtn').onclick = () => guard($('cancelBtn'), () => call('run:cancel'));

const STATUS = { running: 'در حال اجرا', done: 'انجام شد', failed: 'ناموفق' };
let shownRunResult = null;

function renderRun(run) {
  if (!run) return;
  $('runBox').hidden = false;
  $('runTitle').textContent = `${run.label} — ${run.actionTitle}`;
  $('runStatus').textContent = STATUS[run.status];
  $('runStatus').className = 'status ' + run.status;
  $('cancelBtn').hidden = run.status !== 'running';
  $('runLog').innerHTML = run.log.map((l) => `<li>${esc(l.text)}</li>`).join('');
  $('runLog').scrollTop = $('runLog').scrollHeight;
  $('runError').hidden = !run.error;
  $('runError').textContent = run.error || '';
  // اگر ورود شکست خورد، اصلاحِ همان حساب یک کلیک فاصله دارد
  $('runFix').hidden = run.status !== 'failed' || !entries.some((e) => e.id === run.entryId);
  $('runFix').onclick = () => startEdit(run.entryId);
  for (const b of $('actionButtons').children) b.disabled = run.status === 'running';
  if (run.status === 'done') renderSteps({ login: true });

  const r = run.status === 'done' && run.result?.kind === 'sync' ? run.result : null;
  const u = run.status === 'done' && run.result?.kind === 'upload' ? run.result.record : null;
  $('changesBox').hidden = !r && !u;
  if (r) renderChanges(r);
  if (u) {
    $('changesTitle').textContent = run.result.summary;
    $('changesList').innerHTML = [
      ['کارگاه', `${u.code} / شعبه ${u.branchCode}${u.contract ? ' / ردیف پیمان ' + u.contract : ''}`],
      ['تعداد', fa(u.workerCount) + ' نفر'], ['شناسهٔ لیست', u.listId], ['کد رهگیری', u.traceCode || '—'],
    ].map(([k, v]) => `<li><span class="chip">${esc(k)}</span> ${esc(v)}</li>`).join('');
    if (shownRunResult !== run.id) { shownRunResult = run.id; loadUploadHistory(); }
  }
  // بعد از هر همگام‌سازیِ تازه، داده‌های ذخیره‌شدهٔ همان حساب نمایش داده شود
  if (r && shownRunResult !== run.id) {
    shownRunResult = run.id;
    if (entries.some((e) => e.id === run.entryId)) $('runEntry').value = run.entryId;
    loadData(run.entryId);
  }
}

function renderChanges(r) {
  const failed = Object.entries(r.errors || {});
  $('changesTitle').textContent = r.first
    ? 'اولین همگام‌سازی — از دفعهٔ بعد تغییرات این‌جا نمایش داده می‌شوند'
    : r.changeCount ? `${fa(r.changeCount)} تغییر نسبت به دفعهٔ قبل` : 'نسبت به دفعهٔ قبل تغییری نبود';
  $('changesList').innerHTML =
    r.changes.map((c) => `<li><span class="chip">${esc(SECTIONS[c.section]?.title || c.section)}</span> ${esc(c.text)}</li>`).join('') +
    (r.changeCount > r.changes.length ? `<li class="muted">و ${fa(r.changeCount - r.changes.length)} تغییر دیگر…</li>` : '') +
    failed.map(([s, msg]) => `<li class="error">⚠ ${esc(SECTIONS[s]?.title || s)} دریافت نشد: ${esc(msg)}</li>`).join('');
}

// ───────────── داده‌های ذخیره‌شده (بدون مراجعه به سایت) ─────────────

let dataEntryId = null;
let current = null;   // { section, rows, total }
let sort = { key: null, desc: false };

async function loadData(entryId) {
  dataEntryId = entryId;
  if (!entryId) { $('dataCard').hidden = true; return; }
  let sum;
  try { sum = await call('data:summary', { entryId }); } catch (e) { toast(e.message, true); return; }
  if (dataEntryId !== entryId) return;
  $('dataCard').hidden = false;
  $('dataEmpty').hidden = !!sum;
  $('dataBody').hidden = !sum;
  if (!sum) return;

  $('dataMeta').textContent = `آخرین همگام‌سازی: ${faDate(sum.takenAt, true)}`;
  $('dataWhere').textContent = sum.where === 'host'
    ? `ذخیره‌شده روی همین سیستم (برنامهٔ کمکی)${sum.history ? ` — ${fa(sum.history)} نسخه` : ''}`
    : 'فقط تا بستنِ مرورگر نگه داشته می‌شود — برای ذخیرهٔ ماندگار برنامهٔ کمکی را نصب کنید';
  $('dataWhere').className = sum.where === 'host' ? 'muted' : 'hint';

  $('sectionTabs').innerHTML = SECTION_ORDER.map((n) => `
    <button class="tab${sum.errors?.[n] ? ' failed' : ''}" data-section="${n}" title="${esc(sum.errors?.[n] || '')}">
      ${esc(SECTIONS[n].title)} <small>${fa(sum.counts?.[n] || 0)}</small>
    </button>`).join('');
  const keep = current && SECTION_ORDER.includes(current.section) ? current.section : 'workshops';
  await loadSection(keep, sum.errors?.[keep]);
}

async function loadSection(section, error) {
  for (const b of $('sectionTabs').children) b.classList.toggle('active', b.dataset.section === section);
  $('sectionError').hidden = !error;
  $('sectionError').textContent = error ? `این بخش در آخرین همگام‌سازی دریافت نشد: ${error}` : '';
  const { items, total } = await call('data:page', { entryId: dataEntryId, section, offset: 0 });
  current = { section, rows: items, total };
  sort = { key: null, desc: false };
  $('resultFilter').value = '';
  drawTable();
}

$('sectionTabs').onclick = (ev) => {
  const btn = ev.target.closest('[data-section]');
  if (btn) guard(null, () => loadSection(btn.dataset.section, btn.title || null));
};

$('moreBtn').onclick = () => guard($('moreBtn'), async () => {
  const { items } = await call('data:page', { entryId: dataEntryId, section: current.section, offset: current.rows.length });
  current.rows.push(...items);
  drawTable();
});

function drawTable() {
  const columns = SECTIONS[current.section].columns;
  const q = $('resultFilter').value.trim();
  let rows = current.rows;
  if (q) rows = rows.filter((r) => columns.some((c) => String(r[c.key] ?? '').includes(q)));
  if (sort.key) {
    const k = sort.key;
    rows = [...rows].sort((a, b) => {
      const x = a[k], y = b[k];
      const d = typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''), 'fa');
      return sort.desc ? -d : d;
    });
  }
  const moneyCols = columns.filter((c) => c.type === 'money').map((c) => c.key);
  const hot = current.section === 'debts';   // فقط در بدهی‌ها مبلغِ غیرصفر یعنی هشدار
  const cell = (c, v) => c.type === 'money' ? `<td class="money">${v ? fa(v) : '۰'}</td>` : `<td>${esc(v)}</td>`;
  $('resultTable').innerHTML =
    `<thead><tr>${columns.map((c) => `<th data-key="${esc(c.key)}">${esc(c.title)}${sort.key === c.key ? (sort.desc ? ' ▼' : ' ▲') : ''}</th>`).join('')}</tr></thead>` +
    `<tbody>${rows.length ? rows.map((r) => `<tr class="${hot && moneyCols.some((k) => r[k] > 0) ? 'hot' : ''}">${columns.map((c) => cell(c, r[c.key])).join('')}</tr>`).join('')
      : `<tr><td colspan="${columns.length}" class="muted">موردی نیست</td></tr>`}</tbody>`;
  const remaining = current.total - current.rows.length;
  $('moreBtn').hidden = remaining <= 0;
  $('moreBtn').textContent = `${fa(Math.min(remaining, 300))} ردیفِ بیشتر (از ${fa(remaining)} باقی‌مانده)`;
}

$('resultFilter').oninput = () => current && drawTable();
$('resultTable').onclick = (ev) => {
  const key = ev.target.closest('th')?.dataset.key;
  if (!key) return;
  sort = { key, desc: sort.key === key ? !sort.desc : false };
  drawTable();
};

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'run:update') renderRun(msg.run);
  if (msg?.type === 'statement:ready') loadPendingStatement().catch((e) => toast(e.message, true));
});

// ───────────── ارسال لیست بیمه ─────────────

let disk = null;   // { pair: { kar, wor }, s: خلاصه }
let diskCtx = null; // داده‌های ذخیره‌شدهٔ حساب برای پیشنهاد و بررسیِ تکرار

const latin = (s) => String(s ?? '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/\s+/g, '').trim();
const money = (n) => (n === null || n === undefined ? '—' : fa(n) + ' ریال');

function toB64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

/** همهٔ ردیف‌های یک بخش از آخرین همگام‌سازیِ حساب. */
async function allRows(entryId, section) {
  const rows = [];
  for (let offset = 0; ; ) {
    const { items, total } = await call('data:page', { entryId, section, offset });
    rows.push(...items);
    offset += items.length;
    if (!items.length || rows.length >= total) return rows;
  }
}

$('diskFiles').onchange = async (ev) => {
  disk = null;
  $('diskPreview').hidden = true;
  const list = [...ev.target.files];
  if (!list.length) return;
  try {
    const files = [];
    for (const f of list) {
      const buf = await f.arrayBuffer();
      if (/\.zip$/i.test(f.name)) files.push(...(await unzipAll(buf)).filter((x) => /\.dbf$/i.test(x.name)));
      else files.push({ name: f.name, bytes: new Uint8Array(buf) });
    }
    const pair = identifyDisk(files);
    disk = { pair, s: summarizeDisk(pair) };
    await renderDisk();
  } catch (e) {
    toast(e.message, true);
  }
};

async function renderDisk() {
  if (!disk) return;
  const s = disk.s;
  const t = s.totals;
  $('diskFacts').innerHTML = [
    ['کد کارگاه', s.code], ['دوره', s.period], ['تعداد بیمه‌شدگان', fa(s.workerCount)],
    ['جمع روزهای کارکرد', t.days === null ? '—' : fa(t.days)], ['جمع کل دستمزد و مزایا', money(t.gross)],
    ['مشمول', money(t.included)], ['سهم بیمه‌شده', money(t.employee)], ['سهم کارفرما', money(t.employer)],
    ['بیمهٔ بیکاری', money(t.unemployment)],
  ].map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('');
  $('diskIssues').innerHTML = s.issues.length
    ? s.issues.map((i) => `<li class="${i.blocking ? 'error' : 'hint'}">${i.blocking ? '✖' : '⚠'} ${esc(i.text)}</li>`).join('')
    : '<li class="ok">✓ دو فایل با هم سازگارند (کد کارگاه، دوره، تعداد و جمع‌ها)</li>';

  // پیشنهادِ شعبه و ردیف پیمان از آخرین همگام‌سازیِ همین حساب
  const entryId = $('runEntry').value;
  diskCtx = { workshops: [], lists: [], contracts: [] };
  if (entryId && await call('data:summary', { entryId })) {
    [diskCtx.workshops, diskCtx.lists, diskCtx.contracts] = await Promise.all(
      ['workshops', 'lists', 'contracts'].map((n) => allRows(entryId, n).catch(() => [])));
  }
  const branches = diskCtx.workshops.filter((w) => w.code === s.code);
  const contracts = [...new Set([
    ...diskCtx.lists.filter((l) => l.code === s.code && l.contract).map((l) => l.contract),
    ...diskCtx.contracts.filter((c) => c.workshop === s.code && c.row).map((c) => c.row),
  ])];
  disk.knownContracts = contracts;
  $('upBranchList').innerHTML = branches.map((w) => `<option value="${esc(w.branchCode)}">${esc(w.branch || w.name)}</option>`).join('');
  $('upContractList').innerHTML = contracts.map((c) => `<option value="${esc(c)}">ردیف پیمان ${esc(c)}</option>`).join('');
  $('upBranch').value = branches.length === 1 ? branches[0].branchCode : '';
  $('upContract').value = '';
  $('upBranchHint').hidden = branches.length < 2;
  $('upBranchHint').textContent = 'این کارگاه در چند شعبه پرونده دارد؛ شعبه‌ای را انتخاب کنید که لیست باید به آن برود.';

  const label = entries.find((e) => e.id === entryId)?.label || '';
  const synced = diskCtx.workshops.length > 0;
  $('diskAccount').hidden = !synced || branches.length > 0;
  $('diskAccount').textContent = `کارگاهِ ${s.code} در کارگاه‌های حسابِ «${label}» نیست — حسابِ درست را در بخشِ بالا انتخاب کنید.`;
  $('diskPreview').hidden = false;
  checkDup();
}

/** آیا برای همین دوره و مقصد قبلاً لیستِ معتبری ثبت شده؟ (از داده‌های ذخیره‌شده؛ بررسیِ زنده هم هنگامِ اجرا انجام می‌شود) */
function findDup() {
  if (!disk || !diskCtx) return null;
  const s = disk.s, contract = latin($('upContract').value);
  return diskCtx.lists.find((l) => l.code === s.code && (l.contract || '') === contract &&
    (l.year ? l.year % 100 === s.yy && l.month === s.mm : l.period === s.period) &&
    !/غیرقابل ارسال|عدم تایید/.test(l.status)) || null;
}

function checkDup() {
  const dup = findDup();
  $('upDup').hidden = !dup;
  $('upDup').textContent = dup ? `⚠ برای دورهٔ ${disk.s.period} این مقصد از قبل لیستی با وضعیتِ «${dup.status}» ثبت شده است.` : '';
  const blocking = disk?.s.issues.some((i) => i.blocking);
  $('upStart').disabled = !disk || blocking || !$('runEntry').value;
  $('upStart').title = blocking ? 'تا ایرادهای فایل برطرف نشود، ارسال ممکن نیست' : '';
}

$('upContract').oninput = checkDup;
$('upBranch').oninput = checkDup;

$('upStart').onclick = () => guard($('upStart'), async () => {
  const s = disk.s;
  const target = { code: s.code, branchCode: latin($('upBranch').value), contract: latin($('upContract').value) || null };
  if (!/^\d{3,4}$/.test(target.branchCode)) throw new Error('کد شعبه را وارد کنید (مثلاً 0130)');
  if (!$('diskAccount').hidden &&
      !confirm('کد کارگاهِ فایل در کارگاه‌های این حساب نیست. مطمئنید حساب درست است؟')) return;
  let allowDuplicate = false;
  const dup = findDup();
  if (dup) {
    if (!confirm(`برای دورهٔ ${s.period} از قبل لیستی با وضعیتِ «${dup.status}» ثبت شده است.\n\nارسالِ دوباره عمدی است؟`)) return;
    allowDuplicate = true;
  }
  const run = await call('run:start', {
    entryId: $('runEntry').value,
    action: 'upload',
    upload: {
      target, period: s.period, yy: s.yy, mm: s.mm, workerCount: s.workerCount,
      knownContracts: disk.knownContracts || [], allowDuplicate,
      kar: { name: 'DSKKAR00.dbf', b64: toB64(disk.pair.kar.bytes) },
      wor: { name: 'DSKWOR00.dbf', b64: toB64(disk.pair.wor.bytes) },
    },
  });
  renderRun(run);
  $('runBox').scrollIntoView({ behavior: 'smooth', block: 'start' });
});

async function loadUploadHistory() {
  const list = await call('uploads:list');
  $('uploadHistoryBox').hidden = !list.length;
  $('uploadHistory').innerHTML = list.slice(0, 20).map((u) => `
    <li><b>${esc(u.period)}</b> — ${esc(u.label)} — کارگاه ${esc(u.code)}${u.contract ? ' / پیمان ' + esc(u.contract) : ''}
      — ${fa(u.workerCount)} نفر — <span class="chip">${esc(u.status)}</span>
      ${u.traceCode ? ` — رهگیری ${esc(u.traceCode)}` : ''}
      <small class="muted">${esc(faDate(new Date(u.at).toISOString(), true))}</small></li>`).join('');
}

// ───────────── صورتحساب بانکی ─────────────

let stmt = null;         // { statement, file: {name, b64}, shown }
let bankDeliverReady = false;   // ارسالِ فایل (identify-import)
let bankIngestReady = false;    // ثبتِ خودکار (JSON ingest)

function toB64u(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

function updateStmtButtons() {
  const blocking = stmt?.statement.issues.some((i) => i.blocking);
  $('stmtSave').disabled = !stmt || blocking;
  $('stmtDownload').disabled = !stmt;
  // ثبتِ خودکار در حسابداری (JSON ingest) — برای دادهٔ زنده و فایل، هر دو
  $('stmtDeliverLive').disabled = !stmt || blocking || !bankIngestReady;
  // ثبت در حساب زمانی (اتصال ابری) — وقتی به حساب زمانی وارد شده باشیم
  $('stmtDeliverZamani').hidden = !zamaniLoggedIn;
  $('stmtDeliverZamani').disabled = !stmt || blocking;
  // ارسالِ فایلِ اصل (identify-import) — فقط وقتی فایلِ اصل داریم
  $('stmtDeliver').hidden = !stmt || !stmt.file;
  $('stmtDeliver').disabled = !stmt || blocking || !bankDeliverReady || !stmt.file;
  $('stmtDeliverHint').hidden = !stmt || (bankIngestReady || bankDeliverReady);
}

$('stmtFile').onchange = async (ev) => {
  stmt = null;
  $('stmtPreview').hidden = true;
  const file = ev.target.files[0];
  if (!file) return;
  try {
    const buf = await file.arrayBuffer();
    const statement = await parseStatement(file);
    stmt = { statement, file: { name: file.name, b64: toB64u(new Uint8Array(buf)) }, shown: 300 };
    renderStmt();
  } catch (e) {
    toast(e.message, true);
  }
};

// بانک‌های پشتیبانی‌شده برای برچسب‌زدنِ صورتحسابِ فایلی (باید با sites/banks.js هم‌خوان بماند)
const BANKS = [
  { id: 'resalat', code: 'Resalat', slug: 'resalat', title: 'بانک رسالت' },
  { id: 'pasargad', code: 'Pasargad', slug: 'pasargad', title: 'بانک پاسارگاد' },
  { id: 'gardeshgari', code: 'Gardeshgari', slug: 'gardeshgari', title: 'بانک گردشگری' },
];
function applyBankToStmt(bankId) {
  const b = BANKS.find((x) => x.id === bankId) || BANKS[0];
  if (stmt?.statement) { stmt.statement.bankCode = b.code; stmt.statement.bankSlug = b.slug; stmt.statement.bankTitle = b.title; }
}
$('stmtBank').innerHTML = BANKS.map((b) => `<option value="${b.id}">${esc(b.title)}</option>`).join('');
$('stmtBank').onchange = (ev) => applyBankToStmt(ev.target.value);

function renderStmt() {
  const s = stmt.statement;
  // بانک: برای دادهٔ زنده از خودِ صورتحساب، برای فایل از انتخابِ کاربر (پیش‌فرض رسالت)
  const curBank = BANKS.find((b) => b.code === s.bankCode)?.id || 'resalat';
  $('stmtBank').value = curBank;
  applyBankToStmt(curBank);
  const t = s.totals;
  $('stmtFacts').innerHTML = [
    ['شماره حساب', s.accountNumber || '—'], ['تعداد تراکنش', fa(t.count)],
    ['از تاریخ', t.first], ['تا تاریخ', t.last],
    ['جمع برداشت', fa(t.withdraw) + ' ریال'], ['جمع واریز', fa(t.deposit) + ' ریال'],
  ].map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('');
  $('stmtIssues').innerHTML = s.issues.length
    ? s.issues.map((i) => `<li class="${i.blocking ? 'error' : 'hint'}">${i.blocking ? '✖' : '⚠'} ${esc(i.text)}</li>`).join('')
    : '<li class="ok">✓ فایل خوانده شد و پیوستگیِ مانده برقرار است</li>';
  $('stmtPreview').hidden = false;
  drawStmt();
  updateStmtButtons();
  loadStmtHistory();
}

function drawStmt() {
  const s = stmt.statement;
  const q = $('stmtFilter').value.trim();
  let rows = s.rows;
  if (q) rows = rows.filter((r) => s.columns.some((c) => String(r[c.key] ?? '').includes(q)));
  const shown = rows.slice(0, stmt.shown);
  const cell = (c, v) => c.type === 'money'
    ? `<td class="money">${v ? fa(v) : '۰'}</td>`
    : `<td>${esc(v)}</td>`;
  $('stmtTable').innerHTML =
    `<thead><tr>${s.columns.map((c) => `<th>${esc(c.title)}</th>`).join('')}</tr></thead>` +
    `<tbody>${shown.map((r) => `<tr class="${r.withdraw > 0 ? 'hot' : ''}">${s.columns.map((c) => cell(c, r[c.key])).join('')}</tr>`).join('')}</tbody>`;
  const remaining = rows.length - shown.length;
  $('stmtMore').hidden = remaining <= 0;
  $('stmtMore').textContent = `${fa(remaining)} ردیفِ بیشتر`;
}

$('stmtFilter').oninput = () => stmt && drawStmt();
$('stmtMore').onclick = () => { stmt.shown += 300; drawStmt(); };

$('stmtSave').onclick = () => guard($('stmtSave'), async () => {
  const label = entries.find((e) => e.id === $('runEntry').value)?.label || '';
  const r = await call('bank:save', { statement: stmt.statement, meta: { label } });
  toast(r.where === 'host' ? 'صورتحساب روی این سیستم ذخیره شد' : 'صورتحساب تا بستنِ مرورگر نگه داشته شد — برای ذخیرهٔ ماندگار برنامهٔ کمکی را نصب کنید');
  loadStmtHistory();
});

$('stmtDeliverLive').onclick = () => guard($('stmtDeliverLive'), async () => {
  const s = stmt.statement;
  if (!confirm(`ثبتِ خودکارِ ${fa(s.totals.count)} تراکنش (${s.totals.first} تا ${s.totals.last}) در حسابداری از طریق BackupManager؟`)) return;
  const label = entries.find((e) => e.id === $('runEntry').value)?.label || '';
  const data = await call('bank:deliverLive', { statement: s, meta: { accountNumber: s.accountNumber, label } });
  if (data.status === 'Unmatched') toast('ارسال شد ولی شرکتِ این حساب در BackupManager پیدا نشد — حساب را آنجا تعریف کنید', true);
  else toast(`ثبت در حسابداری: ${data.statusFa || data.status || 'انجام شد'}`);
  loadStmtHistory();
});

$('stmtDeliverZamani').onclick = () => guard($('stmtDeliverZamani'), async () => {
  const s = stmt.statement;
  if (!confirm(`ثبتِ ${fa(s.totals.count)} تراکنش (${s.totals.first} تا ${s.totals.last}) در حساب زمانی؟`)) return;
  const label = entries.find((e) => e.id === $('runEntry').value)?.label || '';
  const data = await call('bank:deliverZamani', { statement: s, meta: { accountNumber: s.accountNumber, label } });
  toast(`حساب زمانی: ${data.statusFa || 'انجام شد'}`);
  loadStmtHistory();
});

$('stmtDeliver').onclick = () => guard($('stmtDeliver'), async () => {
  const s = stmt.statement;
  if (!confirm(`ارسالِ ${fa(s.totals.count)} تراکنش (${s.totals.first} تا ${s.totals.last}) به BackupManager روی همین سیستم؟`)) return;
  const label = entries.find((e) => e.id === $('runEntry').value)?.label || '';
  const data = await call('bank:deliver', {
    file: stmt.file,
    meta: { accountNumber: s.accountNumber, count: s.totals.count, from: s.totals.first, to: s.totals.last, label },
  });
  if (data.matched === false) toast('فایل ارسال شد ولی شرکت به‌صورت خودکار شناسایی نشد — در BackupManager بررسی کنید', true);
  else toast(`ارسال شد${data.companyName ? ' — ' + data.companyName : ''}${data.status ? ' (' + data.status + ')' : ''}`);
  loadStmtHistory();
});

$('stmtDownload').onclick = () => {
  if (!stmt) return;
  const s = stmt.statement;
  const esc2 = (v) => { const t = String(v ?? ''); return /[",\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t; };
  const header = s.columns.map((c) => esc2(c.title)).join(',');
  const body = s.rows.map((r) => s.columns.map((c) => esc2(r[c.key])).join(',')).join('\r\n');
  const csv = '﻿' + header + '\r\n' + body;   // BOM تا اکسل فارسی را درست بخواند
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  const acc = (s.accountNumber || 'statement').replace(/[^0-9A-Za-z]/g, '');
  a.href = url;
  a.download = `statement-${acc}-${(s.totals.first || '').replace(/\//g, '')}-${(s.totals.last || '').replace(/\//g, '')}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
};

/** بارگذاریِ صورتحسابِ دریافت‌شدهٔ زنده (یک‌کلیک) که background آماده کرده. */
async function loadPendingStatement() {
  const pending = await call('bank:pending');
  if (!pending) return;
  stmt = { statement: pending.statement, file: null, shown: 300 };
  if (enabledModules.bank) { activeTab = 'bank'; userPickedTab = true; renderTabs(); }
  renderStmt();
  $('bankCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
  toast(`صورتحساب ${pending.label || ''} دریافت شد — بررسی و ذخیره کنید`);
}

async function loadStmtHistory() {
  const list = await call('bank:list');
  $('stmtHistoryBox').hidden = !list.length;
  $('stmtHistory').innerHTML = list.slice(0, 20).map((u) => {
    const kind = u.kind === 'zamani' ? 'ثبت در حساب زمانی' : u.kind === 'ingest' ? 'ثبت در حسابداری' : u.kind === 'deliver' ? 'ارسال فایل' : 'ذخیرهٔ محلی';
    const status = (u.kind === 'deliver' || u.kind === 'ingest' || u.kind === 'zamani')
      ? `${u.company || (u.matched === false ? 'شرکت پیدا نشد' : '')} ${u.result || ''}`.trim()
      : (u.where === 'host' ? 'روی سیستم' : 'موقت');
    return `<li><span class="chip">${esc(kind)}</span> حساب ${esc(u.account || '—')} — ${fa(u.count)} تراکنش (${esc(u.from)} تا ${esc(u.to)})
      ${status ? ' — ' + esc(status) : ''}
      <small class="muted">${esc(faDate(new Date(u.at).toISOString(), true))}</small></li>`;
  }).join('');
}

// ───────────── شروع ─────────────

(async () => {
  try {
    meta = await call('meta');
    $('addSystem').innerHTML = Object.entries(meta.systems).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('');
    renderActions();
    await refresh();
    call('changes:seen').catch(() => {});   // پنل باز شد = تغییرات دیده شد؛ عددِ روی آیکون پاک می‌شود
    const run = await call('run:get');
    if (run?.status === 'done' && run.result?.kind === 'sync') shownRunResult = run.id;
    renderRun(run);
    if (!$('mainView').hidden) await loadData($('runEntry').value);
    await loadUploadHistory();
    await loadStmtHistory();
    await loadPendingStatement();
    await loadZamani();
    if (!$('mainView').hidden) await autoSelectTabForActivePage(true);
  } catch (e) {
    toast(e.message, true);
  }
})();
