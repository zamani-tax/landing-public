// می‌دود در «دنیای اصلیِ» صفحهٔ اینترنت‌بانک (vbank.*) از لحظهٔ document_start.
// تنها کارش: قاپیدنِ هدرِ X-Tab-Session-ID از درخواست‌هایی که خودِ SPAِ بانک به /pols/ می‌زند
// و گذاشتنِ آن روی یک صفتِ DOM تا اسکریپتِ جداشدهٔ افزونه بتواند بخواندش.
// هیچ داده‌ای ارسال نمی‌کند و هیچ درخواستی نمی‌زند؛ فقط هدرِ نشستِ خودِ کاربر را می‌بیند.
// برای همهٔ بانک‌های خانوادهٔ داتین (رسالت، پاسارگاد، گردشگری) یکسان کار می‌کند.

(() => {
  if (window.__zamaniDatinSidHooked) return;
  window.__zamaniDatinSidHooked = true;

  const stash = (v) => {
    if (!v || window.__zamaniDatinSid) return;
    window.__zamaniDatinSid = v;
    try { document.documentElement.setAttribute('data-zamani-sid', v); } catch {}
  };

  const origSet = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    try { if (String(k).toLowerCase() === 'x-tab-session-id') stash(v); } catch {}
    return origSet.apply(this, arguments);
  };

  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      try {
        const h = (init && init.headers) || (input && input.headers);
        if (h) {
          let v = null;
          if (typeof Headers !== 'undefined' && h instanceof Headers) v = h.get('x-tab-session-id');
          else if (Array.isArray(h)) { const e = h.find((p) => String(p[0]).toLowerCase() === 'x-tab-session-id'); v = e && e[1]; }
          else v = h['x-tab-session-id'] || h['X-Tab-Session-ID'];
          stash(v);
        }
      } catch {}
      return origFetch.apply(this, arguments);
    };
  }
})();
