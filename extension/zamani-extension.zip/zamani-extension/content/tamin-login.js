// نوارِ «ورود با دستیار زمانی» روی صفحهٔ ورودِ تأمین.
// این اسکریپت هیچ رمزی دریافت یا ارسال نمی‌کند؛ فقط شناسهٔ حساب را به background می‌فرستد و
// background خودش فرم را پر می‌کند یا (فقط با کلیکِ کاربر روی «ذخیره») آن را می‌خواند.

(() => {
  if (window.__zamaniBar) return;
  window.__zamaniBar = true;

  const send = (type, data = {}) => new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...data }, (res) => {
      resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : res);
    });
  });

  const hasLoginForm = () => !!document.querySelector("input[type='password']");

  function waitForForm(timeoutMs = 30000) {
    return new Promise((resolve) => {
      if (hasLoginForm()) return resolve(true);
      const obs = new MutationObserver(() => { if (hasLoginForm()) { obs.disconnect(); resolve(true); } });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(hasLoginForm()); }, timeoutMs);
    });
  }

  // فونتِ پیدا: @font-face داخلِ Shadow DOM اعمال نمی‌شود، پس در خودِ سند تعریف می‌شود
  // (با نامِ اختصاصی تا با فونت‌های سایت تداخل نکند)
  const fontStyle = document.createElement('style');
  fontStyle.textContent = [400, 500, 700].map((w) => `@font-face{font-family:'ZamaniPeyda';font-weight:${w};font-display:swap;` +
    `src:url('${chrome.runtime.getURL(`fonts/PeydaWebFaNum-${{ 400: 'Regular', 500: 'Medium', 700: 'Bold' }[w]}.woff2`)}') format('woff2');}`).join('');

  // ─── نوار (Shadow DOM تا CSSِ سایت و افزونه روی هم اثر نگذارند) ───
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483647;';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      :host { all: initial; }
      .bar { direction: rtl; font: 400 13.5px/1.7 'ZamaniPeyda', Tahoma, sans-serif; color: #2F3859;
        background: #fff; border: 1px solid #D1D2D4; border-top: 3px solid #C49344; border-radius: 12px;
        padding: 8px 12px; box-shadow: 0 8px 28px rgba(23,39,120,.22);
        display: flex; gap: 8px; align-items: center; flex-wrap: wrap; max-width: min(92vw, 640px); }
      .brand { display: flex; align-items: center; gap: 6px; font-weight: 700; color: #172778; white-space: nowrap; }
      .brand img { width: 22px; height: 22px; }
      .body { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; flex: 1; }
      select, button, input { font: inherit; border-radius: 8px; padding: 4px 10px; }
      select, input { border: 1px solid #D1D2D4; background: #fff; color: #2F3859; max-width: 220px; }
      select:focus, input:focus { outline: none; border-color: #172778; box-shadow: 0 0 0 3px rgba(23,39,120,.2); }
      button { border: 0; background: #172778; color: #fff; font-weight: 500; cursor: pointer; }
      button:hover:not(:disabled) { background: #2F3859; }
      button:disabled { opacity: .5; cursor: default; }
      button.ghost { background: transparent; color: #172778; border: 1px solid #D1D2D4; }
      button.ghost:hover:not(:disabled) { background: #E7E9F4; }
      button.link { background: none; color: #818285; padding: 0; text-decoration: underline; font-weight: 400; }
      button.link:hover:not(:disabled) { background: none; color: #172778; }
      .x { background: transparent; color: #818285; padding: 0 4px; font-size: 18px; }
      .x:hover:not(:disabled) { background: transparent; color: #B50000; }
      .msg { color: #494C5B; }
      .ok { color: #2F3859; font-weight: 500; }
      .warn { color: #8a6424; background: #F2EDE0; border-radius: 6px; padding: 0 8px; }
      .err { color: #B50000; }
    </style>
    <div class="bar">
      <span class="brand"><img src="${chrome.runtime.getURL('icons/icon-48.png')}" alt="">دستیار زمانی</span>
      <span class="body"></span>
      <button class="x" title="بستن">×</button>
    </div>`;
  const body = root.querySelector('.body');
  root.querySelector('.x').onclick = () => host.remove();

  const show = (html) => { body.innerHTML = html; };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // وضعیتِ نوار
  let entries = [];
  let actions = [];
  let lastEntryId = null;   // حسابی که آخرین بار با آن ورود امتحان شد — پیش‌فرضِ «اصلاح»

  // ─── انتخاب حساب و ورود ───

  function renderPicker() {
    if (!entries.length) {
      show(`<span class="msg">هنوز حسابِ تأمینی ذخیره نشده.</span>
        <button class="ghost save-new">ذخیرهٔ همین فرم به‌عنوان حساب</button>`);
      body.querySelector('.save-new').onclick = () => renderSave(null);
      return;
    }
    show(`
      <select class="acc">${entries.map((e) => `<option value="${esc(e.id)}">${esc(e.label)}</option>`).join('')}</select>
      <select class="act">${actions.map((a) => `<option value="${esc(a.id)}">${esc(a.title)}</option>`).join('')}</select>
      <button class="go">ورود</button>
      <button class="link save">ذخیرهٔ فرم در گاوصندوق</button>`);
    if (lastEntryId && entries.some((e) => e.id === lastEntryId)) body.querySelector('.acc').value = lastEntryId;
    const go = body.querySelector('.go');
    go.onclick = async () => {
      go.disabled = true;
      lastEntryId = body.querySelector('.acc').value;
      const res = await send('login:go', { entryId: lastEntryId, action: body.querySelector('.act').value });
      if (!res?.ok) { go.disabled = false; return showError(res?.error); }
      show('<span class="msg">در حال ورود…</span>');
      watchForLoginError();
    };
    body.querySelector('.save').onclick = () => renderSave(body.querySelector('.acc').value);
  }

  // ─── ذخیره یا اصلاح از روی فرمِ سایت (فقط با کلیکِ کاربر) ───

  function renderSave(preselectId) {
    show(`
      <span class="msg">نام کاربری و رمز را در فرمِ سایت درست وارد کنید، سپس:</span>
      <select class="target">
        ${entries.map((e) => `<option value="${esc(e.id)}">اصلاحِ «${esc(e.label)}»</option>`).join('')}
        <option value="">+ حسابِ جدید</option>
      </select>
      <input class="lbl" placeholder="نام شرکت" hidden>
      <button class="do-save">ذخیره در گاوصندوق</button>
      <button class="ghost back">انصراف</button>`);
    const target = body.querySelector('.target');
    const lbl = body.querySelector('.lbl');
    target.value = preselectId && entries.some((e) => e.id === preselectId) ? preselectId : entries.length ? entries[0].id : '';
    const syncLabel = () => { lbl.hidden = target.value !== ''; if (!lbl.hidden) lbl.focus(); };
    target.onchange = syncLabel;
    syncLabel();
    body.querySelector('.back').onclick = renderPicker;
    body.querySelector('.do-save').onclick = async (ev) => {
      const isNew = target.value === '';
      if (isNew && !lbl.value.trim()) { lbl.focus(); return; }
      ev.target.disabled = true;
      const res = await send('login:saveForm', { entryId: isNew ? null : target.value, label: lbl.value });
      if (!res?.ok) { ev.target.disabled = false; return showError(res?.error, true); }
      await reloadEntries();
      lastEntryId = isNew ? entries.find((e) => e.label === res.data.label)?.id : target.value;
      show(`<span class="ok">«${esc(res.data.label)}» در گاوصندوق ذخیره شد.</span>` +
        (res.data.warning ? ` <span class="warn">⚠ ${esc(res.data.warning)}</span>` : '') +
        ' <button class="ghost cont">ادامه</button>');
      body.querySelector('.cont').onclick = renderPicker;
    };
  }

  function showError(error, backToSave = false) {
    show(`<span class="err">${esc(error || 'خطای نامشخص')}</span>
      <button class="ghost fix">اصلاح اطلاعات</button>
      <button class="link retry">بازگشت</button>`);
    body.querySelector('.fix').onclick = () => renderSave(lastEntryId);
    body.querySelector('.retry').onclick = backToSave ? () => renderSave(lastEntryId) : renderPicker;
  }

  /**
   * بعد از ارسالِ فرم، پیامِ خطای سایت را پیدا کن تا کاربر همان‌جا بتواند اصلاح کند و اجرا بی‌جهت
   * منتظر نماند. فقط پیام‌های تازه یا تغییرکرده حساب می‌شوند (نه خطای قبلی که هنوز روی صفحه است).
   */
  function watchForLoginError() {
    const SEL = '.alert, .error, .toast, .message, [role=alert], .invalid-feedback, .text-danger, ' +
      '[class*="error"], [class*="alert"], [class*="danger"], [class*="invalid"]';
    const hints = /نادرست|اشتباه|معتبر نیست|نامعتبر|صحیح نیست|یافت نشد|وجود ندارد|مسدود|طول|رقم می ?باشد|incorrect|invalid/i;
    const baseline = new Map([...document.querySelectorAll(SEL)].map((el) => [el, el.textContent]));
    const started = Date.now();
    const timer = setInterval(() => {
      if (!document.contains(host) || Date.now() - started > 20000) return clearInterval(timer);
      // کوتاه‌ترین عنصرِ منطبق = خودِ پیام، نه ظرفی که کلِ فرم را در بر دارد
      const el = [...document.querySelectorAll(SEL)].filter((x) =>
        x.offsetParent !== null && !host.contains(x) && hints.test(x.textContent) &&
        (!baseline.has(x) || baseline.get(x) !== x.textContent))
        .sort((a, b) => a.textContent.length - b.textContent.length)[0];
      if (el) {
        clearInterval(timer);
        const message = el.textContent.replace(/\s+/g, ' ').trim().slice(0, 200);
        showError(message);
        send('login:failed', { message });
      }
    }, 600);
  }

  async function reloadEntries() {
    const res = await send('login:init');
    if (res?.ok && !res.data.locked) { entries = res.data.entries; actions = res.data.actions; }
  }

  async function init() {
    show('<span class="msg">…</span>');
    const res = await send('login:init');
    if (!res?.ok) return showError(res?.error);
    const d = res.data;
    if (d.locked) {
      show(d.provider === 'native'
        ? '<span class="err">برنامهٔ کمکیِ گاوصندوق در دسترس نیست.</span>'
        : '<span class="msg">گاوصندوق قفل است — روی آیکون افزونه بزنید و باز کنید.</span>');
      body.insertAdjacentHTML('beforeend', ' <button class="ghost retry">تلاش دوباره</button>');
      body.querySelector('.retry').onclick = init;
      return;
    }
    entries = d.entries;
    actions = d.actions;
    if (d.autoFilled) {
      lastEntryId = d.autoFilled.entryId;
      show(`<span class="msg">ورودِ خودکار با «${esc(d.autoFilled.label)}»…</span>`);
      watchForLoginError();
    } else {
      renderPicker();
    }
  }

  (async () => {
    if (!(await waitForForm())) return;
    (document.head || document.documentElement).appendChild(fontStyle);
    document.documentElement.appendChild(host);
    init();
  })();
})();
