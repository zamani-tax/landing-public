// نوارِ «دستیار حسابداری زمانی» روی بانک‌های خانوادهٔ داتین (رسالت، پاسارگاد، گردشگری).
//   oauth.* : دکمهٔ «پر کردن نام کاربری و رمز» (کپچا و ورود با خودِ کاربر، جلوی چشمش).
//   vbank.* : دکمهٔ «دریافت صورتحساب» (یک‌کلیک؛ داده از نشستِ زندهٔ کاربر گرفته می‌شود).
// این اسکریپت هیچ رمزی نمی‌گیرد و هیچ درخواستِ بانکی نمی‌زند؛ فقط پیام به background می‌فرستد.
// background بانکِ درست را از هاستِ همین زبانه تشخیص می‌دهد.

(() => {
  if (window.__zamaniDatinBar) return;
  window.__zamaniDatinBar = true;

  const send = (type, data = {}) => new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...data }, (res) => {
      resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : res);
    });
  });

  const fontStyle = document.createElement('style');
  fontStyle.textContent = [400, 500, 700].map((w) => `@font-face{font-family:'ZamaniPeyda';font-weight:${w};font-display:swap;` +
    `src:url('${chrome.runtime.getURL(`fonts/PeydaWebFaNum-${{ 400: 'Regular', 500: 'Medium', 700: 'Bold' }[w]}.woff2`)}') format('woff2');}`).join('');

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;top:12px;left:12px;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      :host { all: initial; }
      .bar { direction: rtl; font: 400 13.5px/1.7 'ZamaniPeyda', Tahoma, sans-serif; color: #2F3859;
        background: #fff; border: 1px solid #D1D2D4; border-top: 3px solid #C49344; border-radius: 12px;
        padding: 8px 12px; box-shadow: 0 8px 28px rgba(23,39,120,.22);
        display: flex; gap: 8px; align-items: center; flex-wrap: wrap; max-width: min(92vw, 680px); }
      .brand { display: flex; align-items: center; gap: 6px; font-weight: 700; color: #172778; white-space: nowrap; }
      .brand img { width: 22px; height: 22px; }
      .body { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; flex: 1; }
      select, button { font: inherit; border-radius: 8px; padding: 4px 10px; }
      select { border: 1px solid #D1D2D4; background: #fff; color: #2F3859; max-width: 240px; }
      button { border: 0; background: #172778; color: #fff; font-weight: 500; cursor: pointer; }
      button:hover:not(:disabled) { background: #2F3859; }
      button:disabled { opacity: .5; cursor: default; }
      button.ghost { background: transparent; color: #172778; border: 1px solid #D1D2D4; }
      .x { background: transparent; color: #818285; padding: 0 4px; font-size: 18px; }
      .msg { color: #494C5B; } .ok { color: #2F3859; font-weight: 500; } .err { color: #B50000; }
      .tag { color: #172778; font-weight: 700; }
    </style>
    <div class="bar">
      <span class="brand"><img src="${chrome.runtime.getURL('icons/icon-48.png')}" alt="">دستیار حسابداری زمانی</span>
      <span class="tag"></span>
      <span class="body"></span>
      <button class="x" title="بستن">×</button>
    </div>`;
  const body = root.querySelector('.body');
  const tag = root.querySelector('.tag');
  root.querySelector('.x').onclick = () => host.remove();
  const show = (html) => { body.innerHTML = html; };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  let accounts = [], ranges = [];

  function renderLogin() {
    if (!accounts.length) { show('<span class="msg">حسابِ بانکی در گاوصندوق نیست — از پنل افزونه اضافه کنید.</span>'); return; }
    show(`<span class="msg">پر کردنِ خودکار:</span>
      <select class="acc">${accounts.map((a) => `<option value="${esc(a.id)}">${esc(a.label)}</option>`).join('')}</select>
      <button class="fill">پر کردن نام کاربری و رمز</button>`);
    body.querySelector('.fill').onclick = async (ev) => {
      ev.target.disabled = true;
      const res = await send('bank:fillLogin', { entryId: body.querySelector('.acc').value });
      ev.target.disabled = false;
      if (!res?.ok) return show(`<span class="err">${esc(res?.error)}</span>`);
      show(`<span class="ok">پر شد.</span> <span class="msg">${res.data.hasCaptcha ? 'کد امنیتی را وارد و «ورود» را بزنید.' : '«ورود» را بزنید (اگر کد امنیتی خواست، وارد کنید).'}</span>`);
    };
  }

  function renderFetch(chooseDeposit) {
    const accSel = accounts.length
      ? `<select class="acc" title="برای نام‌گذاری در پنل"><option value="">— حساب —</option>${accounts.map((a) => `<option value="${esc(a.id)}">${esc(a.label)}</option>`).join('')}</select>`
      : '';
    const rangeSel = `<select class="rng">${ranges.map((r) => `<option value="${esc(r.id)}">${esc(r.title)}</option>`).join('')}</select>`;
    const depSel = chooseDeposit
      ? `<select class="dep">${chooseDeposit.map((d) => `<option value="${esc(d.depositNumber)}">${esc(d.depositNumber)}${d.depositName ? ' — ' + esc(d.depositName) : ''}</option>`).join('')}</select>`
      : '';
    show(`${accSel}${rangeSel}${depSel}<button class="go">دریافت صورتحساب</button>`);
    body.querySelector('.go').onclick = async () => {
      const entryId = (body.querySelector('.acc') || {}).value || undefined;
      const rangeId = (body.querySelector('.rng') || {}).value;
      const depositNumber = (body.querySelector('.dep') || {}).value || undefined;
      show('<span class="msg">در حال دریافت صورتحساب…</span>');
      const res = await send('bank:fetch', { entryId, rangeId, depositNumber });
      if (res?.ok && res.data?.chooseDeposit) return renderFetch(res.data.chooseDeposit);
      if (!res?.ok) {
        show(`<span class="err">${esc(res?.error)}</span> <button class="ghost retry">تلاش دوباره</button>`);
        body.querySelector('.retry').onclick = () => renderFetch();
        return;
      }
      const d = res.data;
      show(`<span class="ok">${Number(d.count).toLocaleString('fa-IR')} تراکنش دریافت شد (${esc(d.from)} تا ${esc(d.to)}).</span> <span class="msg">در پنل باز شد.</span>
        <button class="ghost again">دریافت دوباره</button>`);
      body.querySelector('.again').onclick = () => renderFetch();
    };
  }

  async function init() {
    show('<span class="msg">…</span>');
    const res = await send('bank:init');
    if (!res?.ok) return show(`<span class="err">${esc(res?.error)}</span>`);
    const d = res.data;
    if (d.bankTitle) tag.textContent = d.bankTitle;
    if (d.locked) { show('<span class="msg">گاوصندوق قفل است — روی آیکون افزونه بزنید و باز کنید.</span> <button class="ghost r">تلاش دوباره</button>'); body.querySelector('.r').onclick = init; return; }
    accounts = d.accounts || []; ranges = d.ranges || [];
    if (d.onLogin) renderLogin(); else renderFetch();
  }

  const start = () => { (document.head || document.documentElement).appendChild(fontStyle); document.documentElement.appendChild(host); init(); };
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start, { once: true });
})();
