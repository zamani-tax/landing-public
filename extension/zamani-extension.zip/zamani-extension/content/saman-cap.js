// می‌دود در «دنیای اصلیِ» صفحهٔ ib.sb24.ir (بانک سامان) از لحظهٔ document_start.
// توکنِ csrf در localStorage است و هنگامِ fetch خوانده می‌شود؛ ولی CurrentUserId و شمارهٔ سپرده
// را باید از درخواست‌هایی که خودِ SPA به billStatement می‌زند برداشت. این اسکریپت آن‌ها را می‌بیند
// و روی صفتِ DOM می‌گذارد تا افزونه بخواندشان. هیچ درخواستی نمی‌زند و هیچ داده‌ای ارسال نمی‌کند.

(() => {
  if (window.__zamaniSamanCap) return;
  window.__zamaniSamanCap = true;

  const setUid = (v) => { if (v && !window.__zamaniSamanUid) { window.__zamaniSamanUid = v; try { document.documentElement.setAttribute('data-zamani-saman-uid', v); } catch {} } };
  const setDep = (v) => { if (v) { window.__zamaniSamanDep = v; try { document.documentElement.setAttribute('data-zamani-saman-dep', v); } catch {} } };

  const grab = (u) => {
    try {
      const q = new URL(u, location.origin).searchParams;
      const dep = q.get('depositNumber');
      if (dep) setDep(dep);
      for (let i = 0; i < 8; i++) {
        if (q.get('data[' + i + '].key') === 'CurrentUserId') {
          const v = q.get('data[' + i + '].value');
          if (v && /^\d+$/.test(v)) setUid(v);
        }
      }
    } catch {}
  };

  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    try { if (url && String(url).indexOf('depositNumber') >= 0) grab(String(url)); } catch {}
    return origOpen.apply(this, arguments);
  };

  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input) {
      try {
        const u = typeof input === 'string' ? input : (input && input.url);
        if (u && String(u).indexOf('depositNumber') >= 0) grab(String(u));
      } catch {}
      return origFetch.apply(this, arguments);
    };
  }
})();
